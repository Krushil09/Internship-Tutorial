# CampusFind — College Lost & Found Portal

**CampusFind** is an institutional-grade, full-stack web application built specifically for university and college campuses. It demonstrates a **strict frontend / backend decoupled architecture**:
- **Frontend**: Pure HTML5, CSS3, and Vanilla JavaScript (Zero frameworks — no React, Vue, Angular, Bootstrap, Tailwind, or jQuery).
- **Backend**: PHP 8+ REST/JSON API layer handling authentication, sessions, database communication, file uploads, claims mediation, and administrative moderation.
- **Database**: MySQL relational database (`college_lost_found`) with foreign keys, constraints, and seed data.

---

## 🏛️ Frontend / Backend Architecture

The frontend communicates with the backend exclusively via HTTP requests using JavaScript `fetch()`. No PHP code is mixed into the HTML presentation layer.

```text
                    FRONTEND
         HTML5 + CSS3 + Vanilla JavaScript
                       │
                       │ HTTP Requests via fetch()
                       ↓
                    BACKEND
               PHP 8+ REST/JSON
                       │
                       │ PDO Prepared Statements
                       ↓
                    DATABASE
                     MySQL
```

---

## 📁 Project Structure

```text
college-lost-found/
│
├── frontend/
│   ├── index.html            # Landing page (hero, categories, recently reported, how it works)
│   ├── login.html            # Student portal sign-in
│   ├── register.html         # Student registration with validation
│   ├── dashboard.html        # Student dashboard with live counters & recent posts
│   ├── lost-items.html       # Browse lost items with real-time & database search
│   ├── found-items.html      # Browse found items with category/location/date filters
│   ├── report-lost.html      # Submit lost item report with photo upload & preview
│   ├── report-found.html     # Submit found item report with location & safekeeping notes
│   ├── item-details.html     # Detailed item view & "I Think This Is Mine" claim modal
│   ├── my-posts.html         # Student's reports management (view, resolve, delete)
│   ├── my-claims.html        # Track submitted claims & review received claims
│   ├── profile.html          # Profile settings, password update & notifications feed
│   │
│   ├── admin/                # Administrator Panel
│   │   ├── login.html        # Dedicated administrator authentication
│   │   ├── dashboard.html    # 6 MySQL metrics cards, pending queue, recent claims
│   │   ├── users.html        # User directory & account activation toggling
│   │   ├── items.html        # Moderate, approve, reject, resolve, and delete items
│   │   └── claims.html       # Verify and accept/reject ownership claims
│   │
│   ├── css/
│   │   └── style.css         # Academic theme (Navy/Blue/Light Gray), CSS grid, zero frameworks
│   │
│   └── js/
│       ├── main.js           # Session nav updates, toast notifications, modals, upload preview
│       ├── auth.js           # Student & admin login, registration, profile & notifications
│       ├── items.js          # Item directories, live search/filtering, reports, details
│       ├── claims.js         # Submit claims, load my claims, review incoming claims
│       └── admin.js          # Admin metrics, user toggles, post approvals, claims verification
│
├── backend/
│   ├── config/
│   │   └── database.php      # PDO database connection, secure sessions, JSON response helpers
│   │
│   ├── auth/
│   │   ├── register.php      # POST: Account creation with bcrypt hashing & welcome alert
│   │   ├── login.php         # POST: Credential verification & session initialization
│   │   ├── logout.php        # GET/POST: Safe session termination & cookie destruction
│   │   └── session.php       # GET/POST: Session inspection, profile update & notifications
│   │
│   ├── items/
│   │   ├── create.php        # POST: Report lost/found item with MIME/size file validation
│   │   ├── read.php          # GET: Filterable item listing (type, search, category, location, mine)
│   │   ├── details.php       # GET: Item details with privacy masking & claim state
│   │   ├── update.php        # POST: Update item details or mark resolved with ownership check
│   │   └── delete.php        # POST: Permanently delete post and clean up image file
│   │
│   ├── claims/
│   │   ├── create.php        # POST: Submit ownership claim with proof & duplicate prevention
│   │   ├── read.php          # GET: Fetch submitted or received claims
│   │   └── update.php        # POST: Accept/reject claim & transition item status
│   │
│   ├── admin/
│   │   ├── users.php         # GET/POST: List users & toggle active/inactive status
│   │   ├── items.php         # GET/POST: Live dashboard metrics, approve/reject/delete items
│   │   └── claims.php        # GET/POST: Claims verification and administrative decisions
│   │
│   └── uploads/
│       └── .htaccess         # Security protection preventing script execution
│
├── database/
│   └── college_lost_found.sql # Schema with users, items, claims, notifications & seed data
│
└── index.html                # Root redirect to frontend/index.html
```

---

## 🎨 Design System

Light, restrained institutional theme reflecting an authentic university portal:

| Color Role | Hex Code | Purpose |
| :--- | :--- | :--- |
| **Primary** | `#1E3A5F` | Dark Navy — headers, brand, primary buttons |
| **Secondary** | `#4F6D8A` | Slate Blue — subtitle, borders, secondary text |
| **Background** | `#F7F8FA` | Off-white canvas |
| **Surface** | `#FFFFFF` | Clean card background |
| **Text Main** | `#1F2933` | Charcoal text |
| **Muted** | `#667085` | Secondary information & timestamps |
| **Border** | `#E4E7EC` | Subtle card & input borders |
| **Success** | `#2E7D32` | Approved & Accepted badges |
| **Warning** | `#B7791F` | Pending status & alerts |
| **Danger** | `#C62828` | Lost badges & delete actions |

---

## 🔑 Demo Login Credentials

The database comes pre-seeded with test accounts:

### 1. Campus Administrator
- **Email**: `admin@campus.edu`
- **Password**: `admin123`
- **Role**: Administrator
- **Access**: [http://localhost/College%20Lost%20&%20Found%20Portal/frontend/admin/login.html](http://localhost/College%20Lost%20&%20Found%20Portal/frontend/admin/login.html)

### 2. Student Accounts
- **Student 1**: `alex.rivera@student.college.edu` | Password: `password123`
- **Student 2**: `emily.chen@student.college.edu` | Password: `password123`
- **Student 3**: `marcus.bell@student.college.edu` | Password: `password123`
- **Access**: [http://localhost/College%20Lost%20&%20Found%20Portal/frontend/login.html](http://localhost/College%20Lost%20&%20Found%20Portal/frontend/login.html)

---

## 🚀 Setup & Execution Guide

1. **Start XAMPP**:
   - Open XAMPP Control Panel.
   - Start **Apache** and **MySQL**.
2. **Access Project**:
   - Web Root: `http://localhost/College%20Lost%20&%20Found%20Portal/`
   - It will automatically route you to `frontend/index.html`.
3. **Database Import (if setting up fresh)**:
   - Open `http://localhost/phpmyadmin/`.
   - Import `database/college_lost_found.sql`.

---

## 🛡️ Security Features Implemented

1. **Strict Decoupling**: HTML/JS only handles presentation and sends `fetch()` requests. No direct database access or PHP logic inside the frontend.
2. **SQL Injection Protection**: 100% prepared statements across all PDO queries with bound parameters.
3. **Password Security**: `password_hash($pwd, PASSWORD_BCRYPT)` and `password_verify()`. No plain-text passwords stored.
4. **Session Fixation Defense**: `session_regenerate_id(true)` upon successful authentication.
5. **Ownership Authorization**: Users can only modify or delete items that belong to them (`user_id === session_user_id`). Modifying an ID in the request will result in an HTTP 403 Forbidden.
6. **Upload Security**:
   - MIME type verified with PHP `finfo` (allowing only JPG, PNG, WEBP).
   - Maximum file size bounded to 5MB.
   - Cryptographically randomized unique filenames.
   - `.htaccess` in `backend/uploads/` prevents script execution.
7. **Cross-Site Scripting (XSS) Prevention**: All dynamic HTML outputs are sanitized via `escapeHtml()`.
