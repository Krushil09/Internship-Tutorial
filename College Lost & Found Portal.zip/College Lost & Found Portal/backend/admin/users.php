<?php
/**
 * CampusFind - Admin Users Management
 * GET /backend/admin/users.php - List all users
 * POST /backend/admin/users.php - Toggle status or manage user
 */

require_once __DIR__ . '/../config/database.php';

$admin = requireAdmin();
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $search = trim($_GET['search'] ?? '');
    $role   = trim($_GET['role'] ?? '');
    $status = trim($_GET['status'] ?? '');

    $conditions = [];
    $params = [];

    if (!empty($search)) {
        $conditions[] = "(u.name LIKE :s1 OR u.email LIKE :s2 OR u.phone LIKE :s3)";
        $params[':s1'] = "%$search%";
        $params[':s2'] = "%$search%";
        $params[':s3'] = "%$search%";
    }

    if (!empty($role)) {
        $conditions[] = "u.role = :role";
        $params[':role'] = $role;
    }

    if (!empty($status)) {
        $conditions[] = "u.status = :status";
        $params[':status'] = $status;
    }

    $where = !empty($conditions) ? 'WHERE ' . implode(' AND ', $conditions) : '';

    $sql = "
        SELECT 
            u.id, u.name, u.email, u.phone, u.role, u.status, u.created_at,
            (SELECT COUNT(*) FROM items i WHERE i.user_id = u.id) AS total_items,
            (SELECT COUNT(*) FROM claims c WHERE c.claimant_id = u.id) AS total_claims
        FROM users u
        $where
        ORDER BY u.created_at DESC
    ";

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $users = $stmt->fetchAll();

    sendJson([
        'success' => true,
        'count'   => count($users),
        'users'   => $users
    ]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = getRequestData();
    $action = $data['action'] ?? '';
    $userId = isset($data['user_id']) ? (int)$data['user_id'] : 0;

    if ($userId <= 0) {
        sendJson(['success' => false, 'message' => 'Valid User ID is required.'], 400);
    }

    // Protect against self-deactivation by the logged-in admin
    if ($userId === (int)$admin['id'] && in_array($action, ['toggle_status', 'deactivate'])) {
        sendJson(['success' => false, 'message' => 'You cannot deactivate your own administrator account.'], 400);
    }

    if ($action === 'toggle_status') {
        $currentStmt = $db->prepare("SELECT status FROM users WHERE id = ?");
        $currentStmt->execute([$userId]);
        $current = $currentStmt->fetchColumn();

        if (!$current) {
            sendJson(['success' => false, 'message' => 'User not found.'], 404);
        }

        $newStatus = ($current === 'active') ? 'inactive' : 'active';
        $upStmt = $db->prepare("UPDATE users SET status = ? WHERE id = ?");
        $upStmt->execute([$newStatus, $userId]);

        sendJson([
            'success'    => true,
            'message'    => "User account marked as {$newStatus}.",
            'new_status' => $newStatus
        ]);
    }

    sendJson(['success' => false, 'message' => 'Invalid action.'], 400);
}
