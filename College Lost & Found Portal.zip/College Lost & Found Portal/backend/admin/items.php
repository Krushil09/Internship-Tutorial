<?php
/**
 * CampusFind - Admin Items Management & Dashboard Statistics
 * GET /backend/admin/items.php?action=stats - Get system statistics
 * GET /backend/admin/items.php - List all items with administrative filters
 * POST /backend/admin/items.php - Approve, reject, resolve, or delete items
 */

require_once __DIR__ . '/../config/database.php';

$admin = requireAdmin();
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $action = $_GET['action'] ?? '';

    // Dashboard Statistics
    if ($action === 'stats') {
        $stats = [
            'total_users'    => (int)$db->query("SELECT COUNT(*) FROM users WHERE role = 'student'")->fetchColumn(),
            'lost_items'     => (int)$db->query("SELECT COUNT(*) FROM items WHERE type = 'lost'")->fetchColumn(),
            'found_items'    => (int)$db->query("SELECT COUNT(*) FROM items WHERE type = 'found'")->fetchColumn(),
            'pending_posts'  => (int)$db->query("SELECT COUNT(*) FROM items WHERE status = 'pending'")->fetchColumn(),
            'active_claims'  => (int)$db->query("SELECT COUNT(*) FROM claims WHERE status = 'pending'")->fetchColumn(),
            'resolved_items' => (int)$db->query("SELECT COUNT(*) FROM items WHERE status IN ('resolved', 'claimed')")->fetchColumn(),
        ];

        // Recent 5 pending items for quick admin review
        $recentPending = $db->query("
            SELECT i.id, i.item_name, i.type, i.category, i.location, i.created_at, u.name AS reporter_name
            FROM items i
            JOIN users u ON i.user_id = u.id
            WHERE i.status = 'pending'
            ORDER BY i.created_at DESC
            LIMIT 5
        ")->fetchAll();

        // Recent 5 claims for quick review
        $recentClaims = $db->query("
            SELECT c.id, c.status, c.created_at, i.item_name, u.name AS claimant_name
            FROM claims c
            JOIN items i ON c.item_id = i.id
            JOIN users u ON c.claimant_id = u.id
            ORDER BY c.created_at DESC
            LIMIT 5
        ")->fetchAll();

        sendJson([
            'success'        => true,
            'stats'          => $stats,
            'recent_pending' => $recentPending,
            'recent_claims'  => $recentClaims
        ]);
    }

    // List all items for items.html
    $status = trim($_GET['status'] ?? '');
    $type   = trim($_GET['type'] ?? '');
    $search = trim($_GET['search'] ?? '');

    $conditions = [];
    $params = [];

    if (!empty($status) && $status !== 'all') {
        $conditions[] = "i.status = :status";
        $params[':status'] = $status;
    }

    if (!empty($type) && in_array($type, ['lost', 'found'], true)) {
        $conditions[] = "i.type = :type";
        $params[':type'] = $type;
    }

    if (!empty($search)) {
        $conditions[] = "(i.item_name LIKE :s1 OR i.location LIKE :s2 OR u.name LIKE :s3)";
        $params[':s1'] = "%$search%";
        $params[':s2'] = "%$search%";
        $params[':s3'] = "%$search%";
    }

    $where = !empty($conditions) ? 'WHERE ' . implode(' AND ', $conditions) : '';

    $sql = "
        SELECT 
            i.*,
            u.name AS reporter_name,
            u.email AS reporter_email,
            (SELECT COUNT(*) FROM claims c WHERE c.item_id = i.id) AS claims_count
        FROM items i
        JOIN users u ON i.user_id = u.id
        $where
        ORDER BY i.created_at DESC
    ";

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $items = $stmt->fetchAll();

    foreach ($items as &$item) {
        $item['image_url'] = !empty($item['image']) ? '../backend/uploads/' . $item['image'] : null;
    }
    unset($item);

    sendJson([
        'success' => true,
        'count'   => count($items),
        'items'   => $items
    ]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = getRequestData();
    $action = $data['action'] ?? '';
    $itemId = isset($data['item_id']) ? (int)$data['item_id'] : (isset($data['id']) ? (int)$data['id'] : 0);

    if ($itemId <= 0) {
        sendJson(['success' => false, 'message' => 'Valid Item ID is required.'], 400);
    }

    // Fetch item
    $stmt = $db->prepare("SELECT id, user_id, item_name, image, status FROM items WHERE id = ?");
    $stmt->execute([$itemId]);
    $item = $stmt->fetch();

    if (!$item) {
        sendJson(['success' => false, 'message' => 'Item not found.'], 404);
    }

    if ($action === 'approve') {
        $up = $db->prepare("UPDATE items SET status = 'approved', updated_at = NOW() WHERE id = ?");
        $up->execute([$itemId]);

        addNotification(
            $db,
            (int)$item['user_id'],
            'Post Approved',
            "Your post for \"{$item['item_name']}\" has been approved and published to CampusFind."
        );

        sendJson(['success' => true, 'message' => 'Item post has been approved and published.']);
    }

    if ($action === 'reject') {
        $reason = trim($data['reason'] ?? 'Did not meet campus posting guidelines');
        $up = $db->prepare("UPDATE items SET status = 'rejected', updated_at = NOW() WHERE id = ?");
        $up->execute([$itemId]);

        addNotification(
            $db,
            (int)$item['user_id'],
            'Post Rejected',
            "Your post for \"{$item['item_name']}\" was rejected: {$reason}."
        );

        sendJson(['success' => true, 'message' => 'Item post has been marked as rejected.']);
    }

    if ($action === 'resolve') {
        $up = $db->prepare("UPDATE items SET status = 'resolved', updated_at = NOW() WHERE id = ?");
        $up->execute([$itemId]);

        addNotification(
            $db,
            (int)$item['user_id'],
            'Item Resolved',
            "The administrator marked your post \"{$item['item_name']}\" as resolved."
        );

        sendJson(['success' => true, 'message' => 'Item marked as resolved.']);
    }

    if ($action === 'delete') {
        if (!empty($item['image'])) {
            $imgPath = UPLOADS_DIR . DIRECTORY_SEPARATOR . $item['image'];
            if (file_exists($imgPath)) {
                @unlink($imgPath);
            }
        }

        $del = $db->prepare("DELETE FROM items WHERE id = ?");
        $del->execute([$itemId]);

        addNotification(
            $db,
            (int)$item['user_id'],
            'Post Removed',
            "Your post for \"{$item['item_name']}\" was removed by the administrator."
        );

        sendJson(['success' => true, 'message' => 'Item permanently deleted.']);
    }

    sendJson(['success' => false, 'message' => 'Invalid action.'], 400);
}
