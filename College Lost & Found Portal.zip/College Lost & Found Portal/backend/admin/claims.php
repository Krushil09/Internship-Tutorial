<?php
/**
 * CampusFind - Admin Claims Management
 * GET /backend/admin/claims.php - List all claims
 * POST /backend/admin/claims.php - Accept or reject claims
 */

require_once __DIR__ . '/../config/database.php';

$admin = requireAdmin();
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $status = trim($_GET['status'] ?? '');
    $search = trim($_GET['search'] ?? '');

    $conditions = [];
    $params = [];

    if (!empty($status) && $status !== 'all') {
        $conditions[] = "c.status = :status";
        $params[':status'] = $status;
    }

    if (!empty($search)) {
        $conditions[] = "(i.item_name LIKE :s1 OR u.name LIKE :s2 OR rep.name LIKE :s3 OR c.message LIKE :s4)";
        $params[':s1'] = "%$search%";
        $params[':s2'] = "%$search%";
        $params[':s3'] = "%$search%";
        $params[':s4'] = "%$search%";
    }

    $where = !empty($conditions) ? 'WHERE ' . implode(' AND ', $conditions) : '';

    $sql = "
        SELECT 
            c.id, c.item_id, c.claimant_id, c.message, c.contact_info, c.status, c.created_at, c.updated_at,
            i.item_name, i.type AS item_type, i.category AS item_category, i.location AS item_location, i.image AS item_image,
            u.name AS claimant_name, u.email AS claimant_email, u.phone AS claimant_phone,
            rep.id AS reporter_id, rep.name AS reporter_name, rep.email AS reporter_email
        FROM claims c
        JOIN items i ON c.item_id = i.id
        JOIN users u ON c.claimant_id = u.id
        JOIN users rep ON i.user_id = rep.id
        $where
        ORDER BY c.created_at DESC
    ";

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $claims = $stmt->fetchAll();

    foreach ($claims as &$claim) {
        $claim['item_image_url'] = !empty($claim['item_image']) ? '../backend/uploads/' . $claim['item_image'] : null;
    }
    unset($claim);

    sendJson([
        'success' => true,
        'count'   => count($claims),
        'claims'  => $claims
    ]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = getRequestData();
    $claimId = isset($data['claim_id']) ? (int)$data['claim_id'] : (isset($data['id']) ? (int)$data['id'] : 0);
    $status  = strtolower(trim($data['status'] ?? ''));

    if ($claimId <= 0) {
        sendJson(['success' => false, 'message' => 'Valid Claim ID is required.'], 400);
    }

    if (!in_array($status, ['accepted', 'rejected'], true)) {
        sendJson(['success' => false, 'message' => 'Status must be "accepted" or "rejected".'], 422);
    }

    $stmt = $db->prepare("
        SELECT c.id, c.item_id, c.claimant_id, i.user_id AS reporter_id, i.item_name
        FROM claims c
        JOIN items i ON c.item_id = i.id
        WHERE c.id = ?
        LIMIT 1
    ");
    $stmt->execute([$claimId]);
    $claim = $stmt->fetch();

    if (!$claim) {
        sendJson(['success' => false, 'message' => 'Claim not found.'], 404);
    }

    try {
        $db->beginTransaction();

        $up = $db->prepare("UPDATE claims SET status = ?, updated_at = NOW() WHERE id = ?");
        $up->execute([$status, $claimId]);

        if ($status === 'accepted') {
            $db->prepare("UPDATE items SET status = 'claimed', updated_at = NOW() WHERE id = ?")->execute([$claim['item_id']]);

            addNotification(
                $db,
                (int)$claim['claimant_id'],
                'Claim Accepted by Administrator',
                "Your claim for \"{$claim['item_name']}\" was approved by the campus administrator. Please proceed to campus security desk for pickup."
            );

            addNotification(
                $db,
                (int)$claim['reporter_id'],
                'Item Claim Approved',
                "An ownership claim for your reported item \"{$claim['item_name']}\" was verified and approved by the campus administrator."
            );
        } else {
            addNotification(
                $db,
                (int)$claim['claimant_id'],
                'Claim Rejected by Administrator',
                "Your claim for \"{$claim['item_name']}\" was reviewed by administration and not accepted."
            );
        }

        $db->commit();

        sendJson(['success' => true, 'message' => 'Claim status updated to ' . ucfirst($status) . '.']);

    } catch (Exception $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        sendJson(['success' => false, 'message' => 'Error updating claim: ' . $e->getMessage()], 500);
    }
}
