<?php
/**
 * CampusFind - Login Endpoint
 * POST /backend/auth/login.php
 */

require_once __DIR__ . '/../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJson(['success' => false, 'message' => 'Invalid request method. Expected POST.'], 405);
}

$data     = getRequestData();
$email    = strtolower(trim($data['email'] ?? ''));
$password = $data['password'] ?? '';
$portal   = strtolower(trim($data['portal'] ?? ''));

// Validate inputs
if (empty($email) || empty($password)) {
    $msg = ($portal === 'admin') 
        ? 'Please enter both administrator email and password.' 
        : 'Please enter both email and password.';
    sendJson(['success' => false, 'message' => $msg], 422);
}

$db = getDB();
$stmt = $db->prepare("SELECT id, name, email, phone, password, role, status FROM users WHERE email = ? LIMIT 1");
$stmt->execute([$email]);
$user = $stmt->fetch();

// Admin Portal Specific Verification
if ($portal === 'admin') {
    // Check credentials and ensure role is genuinely admin
    if (!$user || !password_verify($password, $user['password']) || $user['role'] !== 'admin') {
        sendJson(['success' => false, 'message' => 'Invalid administrator credentials.'], 401);
    }

    if ($user['status'] !== 'active') {
        sendJson(['success' => false, 'message' => 'Administrator account has been deactivated.'], 403);
    }

    initSession();
    if (!empty($_COOKIE[session_name()])) {
        session_regenerate_id(true);
    }

    $_SESSION['user'] = [
        'id'    => (int)$user['id'],
        'name'  => $user['name'],
        'email' => $user['email'],
        'phone' => $user['phone'],
        'role'  => 'admin'
    ];

    sendJson([
        'success'  => true,
        'message'  => 'Administrator authentication successful. Welcome, ' . htmlspecialchars($user['name']) . '!',
        'redirect' => 'dashboard.html',
        'user'     => $_SESSION['user']
    ]);
}

// Student Portal Specific Verification
if ($portal === 'student') {
    if (!$user || !password_verify($password, $user['password'])) {
        sendJson(['success' => false, 'message' => 'Invalid student credentials.'], 401);
    }

    // Role protection: Administrator cannot log into student portal as a student
    if ($user['role'] === 'admin') {
        sendJson(['success' => false, 'message' => 'Administrator accounts must sign in via the Admin Portal.'], 403);
    }

    if ($user['status'] !== 'active') {
        sendJson(['success' => false, 'message' => 'Your student account has been deactivated. Please contact campus security/admin.'], 403);
    }

    initSession();
    if (!empty($_COOKIE[session_name()])) {
        session_regenerate_id(true);
    }

    $_SESSION['user'] = [
        'id'    => (int)$user['id'],
        'name'  => $user['name'],
        'email' => $user['email'],
        'phone' => $user['phone'],
        'role'  => 'student'
    ];

    sendJson([
        'success'  => true,
        'message'  => 'Login successful. Welcome back, ' . htmlspecialchars($user['name']) . '!',
        'redirect' => 'dashboard.html',
        'user'     => $_SESSION['user']
    ]);
}

// Fallback general login
if (!$user || !password_verify($password, $user['password'])) {
    sendJson(['success' => false, 'message' => 'Invalid email or password.'], 401);
}

if ($user['status'] !== 'active') {
    sendJson(['success' => false, 'message' => 'Your account has been deactivated.'], 403);
}

initSession();
if (!empty($_COOKIE[session_name()])) {
    session_regenerate_id(true);
}

$_SESSION['user'] = [
    'id'    => (int)$user['id'],
    'name'  => $user['name'],
    'email' => $user['email'],
    'phone' => $user['phone'],
    'role'  => $user['role']
];

$redirectUrl = ($user['role'] === 'admin') ? 'admin/dashboard.html' : 'dashboard.html';

sendJson([
    'success'  => true,
    'message'  => 'Login successful. Welcome back, ' . htmlspecialchars($user['name']) . '!',
    'redirect' => $redirectUrl,
    'user'     => $_SESSION['user']
]);
