<?php
/**
 * CampusFind - Logout Endpoint
 * POST or GET /backend/auth/logout.php
 */

require_once __DIR__ . '/../config/database.php';

initSession();

$portal = strtolower(trim($_GET['portal'] ?? ($_POST['portal'] ?? '')));
$user = $_SESSION['user'] ?? null;
if (empty($portal) && ($user['role'] ?? '') === 'admin') {
    $portal = 'admin';
}

// Clear session variables
$_SESSION = [];

// Destroy session cookie
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
}

session_destroy();

$redirect = ($portal === 'admin') ? 'admin/login.html' : 'login.html';

sendJson([
    'success'  => true,
    'message'  => 'Logged out successfully.',
    'redirect' => $redirect
]);
