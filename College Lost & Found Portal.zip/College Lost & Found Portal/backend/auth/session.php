<?php
/**
 * CampusFind - Session & Profile Endpoint
 * GET /backend/auth/session.php - Retrieve current session data
 * POST /backend/auth/session.php - Update user profile & password
 */

require_once __DIR__ . '/../config/database.php';

initSession();

$user = getCurrentUser();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (!$user) {
        sendJson([
            'success'   => true,
            'logged_in' => false,
            'user'      => null
        ]);
    }

    $db = getDB();
    // Get fresh user record from database
    $stmt = $db->prepare("SELECT id, name, email, phone, role, status, created_at FROM users WHERE id = ?");
    $stmt->execute([(int)$user['id']]);
    $userData = $stmt->fetch();

    if (!$userData || $userData['status'] !== 'active') {
        // Inactive or deleted user
        $_SESSION = [];
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params["path"], $params["domain"], $params["secure"], $params["httponly"]);
        }
        session_destroy();
        sendJson([
            'success'   => true,
            'logged_in' => false,
            'user'      => null
        ]);
    }

    // Role-specific check if requested
    $expectedRole = trim($_GET['role'] ?? ($_GET['portal'] ?? ''));
    if (!empty($expectedRole)) {
        if ($expectedRole === 'admin' && $userData['role'] !== 'admin') {
            sendJson([
                'success'   => true,
                'logged_in' => false,
                'role'      => $userData['role'],
                'message'   => 'Access denied. Administrator privileges required.',
                'user'      => null
            ]);
        }
        if ($expectedRole === 'student' && $userData['role'] !== 'student') {
            sendJson([
                'success'   => true,
                'logged_in' => false,
                'role'      => $userData['role'],
                'message'   => 'Administrator account must use the Admin Console.',
                'user'      => null
            ]);
        }
    }

    $uid = (int)$userData['id'];

    // Get count of user's posts, claims, unread notifications with safe positional placeholders
    $countsStmt = $db->prepare("
        SELECT 
            (SELECT COUNT(*) FROM items WHERE user_id = ? AND type = 'lost') AS lost_count,
            (SELECT COUNT(*) FROM items WHERE user_id = ? AND type = 'found') AS found_count,
            (SELECT COUNT(*) FROM claims WHERE claimant_id = ?) AS claims_count,
            (SELECT COUNT(*) FROM items WHERE user_id = ? AND status = 'resolved') AS resolved_count,
            (SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0) AS unread_notifications
    ");
    $countsStmt->execute([$uid, $uid, $uid, $uid, $uid]);
    $stats = $countsStmt->fetch();

    // Get recent notifications
    $notifStmt = $db->prepare("SELECT id, title, message, is_read, created_at FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 5");
    $notifStmt->execute([$uid]);
    $notifications = $notifStmt->fetchAll();

    sendJson([
        'success'       => true,
        'logged_in'     => true,
        'user'          => $userData,
        'is_admin'      => ($userData['role'] === 'admin'),
        'stats'         => $stats ?: [
            'lost_count'           => 0,
            'found_count'          => 0,
            'claims_count'         => 0,
            'resolved_count'       => 0,
            'unread_notifications' => 0
        ],
        'notifications' => $notifications ?: []
    ]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $currentUser = requireAuth();
    $data = getRequestData();
    $action = $data['action'] ?? 'update_profile';

    $db = getDB();

    if ($action === 'mark_notifications_read') {
        $stmt = $db->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
        $stmt->execute([(int)$currentUser['id']]);
        sendJson(['success' => true, 'message' => 'Notifications marked as read.']);
    }

    if ($action === 'update_profile') {
        $name = trim($data['name'] ?? '');
        $phone = trim($data['phone'] ?? '');
        $currentPassword = $data['current_password'] ?? '';
        $newPassword = $data['new_password'] ?? '';

        if (empty($name)) {
            sendJson(['success' => false, 'message' => 'Full Name cannot be empty.'], 422);
        }

        if (empty($phone)) {
            sendJson(['success' => false, 'message' => 'Phone number cannot be empty.'], 422);
        }

        // If user wants to change password
        if (!empty($newPassword)) {
            if (empty($currentPassword)) {
                sendJson(['success' => false, 'message' => 'Please provide your current password to set a new password.'], 422);
            }
            if (strlen($newPassword) < 6) {
                sendJson(['success' => false, 'message' => 'New password must be at least 6 characters.'], 422);
            }

            // Verify current password
            $pwdStmt = $db->prepare("SELECT password FROM users WHERE id = ?");
            $pwdStmt->execute([(int)$currentUser['id']]);
            $currentHash = $pwdStmt->fetchColumn();

            if (!password_verify($currentPassword, $currentHash)) {
                sendJson(['success' => false, 'message' => 'Current password is incorrect.'], 401);
            }

            $newHash = password_hash($newPassword, PASSWORD_BCRYPT);
            $updateStmt = $db->prepare("UPDATE users SET name = ?, phone = ?, password = ? WHERE id = ?");
            $updateStmt->execute([$name, $phone, $newHash, (int)$currentUser['id']]);
        } else {
            $updateStmt = $db->prepare("UPDATE users SET name = ?, phone = ? WHERE id = ?");
            $updateStmt->execute([$name, $phone, (int)$currentUser['id']]);
        }

        $_SESSION['user']['name'] = $name;
        $_SESSION['user']['phone'] = $phone;

        sendJson([
            'success' => true,
            'message' => 'Profile updated successfully!',
            'user'    => $_SESSION['user']
        ]);
    }

    sendJson(['success' => false, 'message' => 'Invalid action.'], 400);
}
