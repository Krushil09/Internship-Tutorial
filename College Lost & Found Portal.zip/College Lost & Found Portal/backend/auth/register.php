<?php
/**
 * CampusFind - Registration Endpoint
 * POST /backend/auth/register.php
 */

require_once __DIR__ . '/../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJson(['success' => false, 'message' => 'Invalid request method. Expected POST.'], 405);
}

$data = getRequestData();

$name = trim($data['name'] ?? '');
$email = strtolower(trim($data['email'] ?? ''));
$phone = trim($data['phone'] ?? '');
$password = $data['password'] ?? '';
$confirmPassword = $data['confirm_password'] ?? '';

// Validation
if (empty($name)) {
    sendJson(['success' => false, 'message' => 'Full Name is required.'], 422);
}

if (strlen($name) < 2 || strlen($name) > 100) {
    sendJson(['success' => false, 'message' => 'Full Name must be between 2 and 100 characters.'], 422);
}

if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    sendJson(['success' => false, 'message' => 'Please provide a valid email address.'], 422);
}

if (empty($phone)) {
    sendJson(['success' => false, 'message' => 'Phone number is required.'], 422);
}

if (empty($password)) {
    sendJson(['success' => false, 'message' => 'Password is required.'], 422);
}

if (strlen($password) < 6) {
    sendJson(['success' => false, 'message' => 'Password must be at least 6 characters long.'], 422);
}

if ($password !== $confirmPassword) {
    sendJson(['success' => false, 'message' => 'Passwords do not match.'], 422);
}

$db = getDB();

// Check if email already exists
$stmt = $db->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
$stmt->execute([$email]);
if ($stmt->fetch()) {
    sendJson(['success' => false, 'message' => 'This email address is already registered. Please log in.'], 409);
}

// Hash password securely
$hashedPassword = password_hash($password, PASSWORD_BCRYPT);

try {
    $insertStmt = $db->prepare("
        INSERT INTO users (name, email, phone, password, role, status, created_at)
        VALUES (?, ?, ?, ?, 'student', 'active', NOW())
    ");
    $insertStmt->execute([$name, $email, $phone, $hashedPassword]);
    $newUserId = (int)$db->lastInsertId();

    // Welcome notification
    addNotification(
        $db,
        $newUserId,
        'Welcome to CampusFind!',
        'Your student account has been created. You can now report lost or found items and submit claims.'
    );

    sendJson([
        'success' => true,
        'message' => 'Registration successful! You can now log in to your account.',
        'redirect' => 'login.html'
    ], 201);
} catch (Exception $e) {
    sendJson(['success' => false, 'message' => 'Registration failed. Please try again later.'], 500);
}
