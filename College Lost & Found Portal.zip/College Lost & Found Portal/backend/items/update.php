<?php
/**
 * CampusFind - Update Item
 * POST /backend/items/update.php
 */

require_once __DIR__ . '/../config/database.php';

$currentUser = requireAuth();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJson(['success' => false, 'message' => 'Invalid request method. Expected POST.'], 405);
}

$data = !empty($_POST) ? $_POST : getRequestData();
$id = isset($data['id']) ? (int)$data['id'] : 0;

if ($id <= 0) {
    sendJson(['success' => false, 'message' => 'Valid Item ID is required.'], 400);
}

$db = getDB();

// Fetch existing item to check ownership
$stmt = $db->prepare("SELECT * FROM items WHERE id = ? LIMIT 1");
$stmt->execute([$id]);
$item = $stmt->fetch();

if (!$item) {
    sendJson(['success' => false, 'message' => 'Item not found.'], 404);
}

$isOwner = ((int)$item['user_id'] === (int)$currentUser['id']);
$isAdmin = (($currentUser['role'] ?? '') === 'admin');

if (!$isOwner && !$isAdmin) {
    sendJson(['success' => false, 'message' => 'Unauthorized. You can only modify your own posts.'], 403);
}

// Quick action: status update only (e.g. mark resolved)
if (isset($data['action']) && $data['action'] === 'status_change') {
    $newStatus = trim($data['status'] ?? '');
    $allowedStatuses = ['resolved', 'claimed'];
    if ($isAdmin) {
        $allowedStatuses = ['pending', 'approved', 'claimed', 'resolved', 'rejected'];
    }

    if (!in_array($newStatus, $allowedStatuses, true)) {
        sendJson(['success' => false, 'message' => 'Invalid status transition.'], 422);
    }

    $updateStmt = $db->prepare("UPDATE items SET status = ?, updated_at = NOW() WHERE id = ?");
    $updateStmt->execute([$newStatus, $id]);

    sendJson([
        'success' => true,
        'message' => "Item status updated to " . ucfirst($newStatus) . "."
    ]);
}

// Full item edit
$itemName       = trim($data['item_name'] ?? $item['item_name']);
$category       = trim($data['category'] ?? $item['category']);
$description    = trim($data['description'] ?? $item['description']);
$location       = trim($data['location'] ?? $item['location']);
$itemDate       = trim($data['item_date'] ?? $item['item_date']);
$approxTime     = trim($data['approx_time'] ?? $item['approx_time']);
$additionalInfo = trim($data['additional_info'] ?? $item['additional_info']);

if (empty($itemName)) {
    sendJson(['success' => false, 'message' => 'Item name cannot be empty.'], 422);
}
if (empty($description)) {
    sendJson(['success' => false, 'message' => 'Description cannot be empty.'], 422);
}
if (empty($location)) {
    sendJson(['success' => false, 'message' => 'Location cannot be empty.'], 422);
}

$uploadedFilename = $item['image'];

// Check if new image was uploaded
if (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
    $file = $_FILES['image'];

    if ($file['size'] > 5 * 1024 * 1024) {
        sendJson(['success' => false, 'message' => 'Image exceeds 5MB limit.'], 422);
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mimeType = $finfo->file($file['tmp_name']);
    $allowedMimes = [
        'image/jpeg' => 'jpg',
        'image/pjpeg'=> 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp'
    ];

    if (!array_key_exists($mimeType, $allowedMimes)) {
        sendJson(['success' => false, 'message' => 'Invalid image format.'], 422);
    }

    $newFilename = 'item_' . time() . '_' . bin2hex(random_bytes(8)) . '.' . $allowedMimes[$mimeType];
    $targetPath = UPLOADS_DIR . DIRECTORY_SEPARATOR . $newFilename;

    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        // Delete old image if it exists
        if (!empty($item['image']) && file_exists(UPLOADS_DIR . DIRECTORY_SEPARATOR . $item['image'])) {
            @unlink(UPLOADS_DIR . DIRECTORY_SEPARATOR . $item['image']);
        }
        $uploadedFilename = $newFilename;
    }
}

$updateSql = "
    UPDATE items 
    SET item_name = ?, category = ?, description = ?, location = ?, item_date = ?, approx_time = ?, additional_info = ?, image = ?, updated_at = NOW()
    WHERE id = ?
";
$updateStmt = $db->prepare($updateSql);
$updateStmt->execute([
    $itemName,
    $category,
    $description,
    $location,
    $itemDate,
    $approxTime ?: null,
    $additionalInfo ?: null,
    $uploadedFilename,
    $id
]);

sendJson([
    'success' => true,
    'message' => 'Item updated successfully.'
]);
