<?php
/**
 * CampusFind - Create Item Report (Lost or Found)
 * POST /backend/items/create.php
 */

require_once __DIR__ . '/../config/database.php';

$user = requireAuth();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJson(['success' => false, 'message' => 'Invalid request method. Expected POST.'], 405);
}

// Support both FormData / $_POST and JSON
$data = !empty($_POST) ? $_POST : getRequestData();

$type           = strtolower(trim($data['type'] ?? ''));
$itemName       = trim($data['item_name'] ?? '');
$category       = trim($data['category'] ?? '');
$description    = trim($data['description'] ?? '');
$location       = trim($data['location'] ?? '');
$itemDate       = trim($data['item_date'] ?? '');
$approxTime     = trim($data['approx_time'] ?? '');
$additionalInfo = trim($data['additional_info'] ?? '');

// Validation
if (!in_array($type, ['lost', 'found'], true)) {
    sendJson(['success' => false, 'message' => 'Invalid item type. Must be "lost" or "found".'], 422);
}

if (empty($itemName)) {
    sendJson(['success' => false, 'message' => 'Item name is required.'], 422);
}

$validCategories = ['ID Cards', 'Electronics', 'Wallets', 'Keys', 'Books', 'Bags', 'Documents', 'Accessories', 'Other'];
if (empty($category) || !in_array($category, $validCategories, true)) {
    sendJson(['success' => false, 'message' => 'Please select a valid item category.'], 422);
}

if (empty($description)) {
    sendJson(['success' => false, 'message' => 'Description is required.'], 422);
}

if (empty($location)) {
    sendJson(['success' => false, 'message' => 'Campus location is required.'], 422);
}

if (empty($itemDate) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $itemDate)) {
    sendJson(['success' => false, 'message' => 'A valid date (YYYY-MM-DD) is required.'], 422);
}

// Process Image Upload
$uploadedFilename = null;

if (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
    $file = $_FILES['image'];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        sendJson(['success' => false, 'message' => 'File upload error code: ' . $file['error']], 400);
    }

    // Validate size (max 5MB)
    if ($file['size'] > 5 * 1024 * 1024) {
        sendJson(['success' => false, 'message' => 'Image file size exceeds maximum limit of 5MB.'], 422);
    }

    // Validate MIME type securely using finfo
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mimeType = $finfo->file($file['tmp_name']);
    $allowedMimes = [
        'image/jpeg' => 'jpg',
        'image/pjpeg'=> 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp'
    ];

    if (!array_key_exists($mimeType, $allowedMimes)) {
        sendJson(['success' => false, 'message' => 'Invalid image format. Allowed formats: JPG, JPEG, PNG, WEBP.'], 422);
    }

    // Validate extension
    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $validExtensions = ['jpg', 'jpeg', 'png', 'webp'];
    if (!in_array($extension, $validExtensions, true)) {
        sendJson(['success' => false, 'message' => 'Invalid file extension.'], 422);
    }

    // Generate unique, safe filename
    $uploadedFilename = 'item_' . time() . '_' . bin2hex(random_bytes(8)) . '.' . $allowedMimes[$mimeType];
    $targetPath = UPLOADS_DIR . DIRECTORY_SEPARATOR . $uploadedFilename;

    if (!is_dir(UPLOADS_DIR)) {
        mkdir(UPLOADS_DIR, 0755, true);
    }

    if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
        sendJson(['success' => false, 'message' => 'Failed to save uploaded image.'], 500);
    }
}

$db = getDB();

try {
    // If admin is reporting, automatically approve; students start as pending
    $initialStatus = ($user['role'] === 'admin') ? 'approved' : 'pending';

    $stmt = $db->prepare("
        INSERT INTO items (
            user_id, type, item_name, category, description,
            location, item_date, approx_time, image, additional_info,
            status, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
    ");

    $stmt->execute([
        $user['id'],
        $type,
        $itemName,
        $category,
        $description,
        $location,
        $itemDate,
        $approxTime ?: null,
        $uploadedFilename,
        $additionalInfo ?: null,
        $initialStatus
    ]);

    $itemId = (int)$db->lastInsertId();

    // Create user notification
    $title = ($type === 'lost') ? 'Lost Item Reported' : 'Found Item Reported';
    $message = ($initialStatus === 'pending')
        ? "Your report for \"{$itemName}\" has been submitted and is pending administrative approval."
        : "Your report for \"{$itemName}\" has been published to the portal.";
    
    addNotification($db, $user['id'], $title, $message);

    sendJson([
        'success'   => true,
        'message'   => ($initialStatus === 'pending')
            ? 'Report submitted successfully! It will appear on the portal once reviewed by the campus administrator.'
            : 'Item reported and published successfully!',
        'item_id'   => $itemId,
        'status'    => $initialStatus,
        'redirect'  => 'my-posts.html'
    ], 201);

} catch (Exception $e) {
    sendJson(['success' => false, 'message' => 'Failed to create item: ' . $e->getMessage()], 500);
}
