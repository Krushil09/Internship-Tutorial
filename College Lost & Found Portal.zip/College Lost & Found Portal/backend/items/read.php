<?php
/**
 * CampusFind - Read Items Listing
 * GET /backend/items/read.php
 * Query Params:
 *  - type: 'lost' | 'found' | '' (all)
 *  - category: string
 *  - location: string
 *  - search: keyword in item_name, description, location
 *  - date_from, date_to: YYYY-MM-DD
 *  - mine: 'true' | '1' (current user items only)
 *  - recent: 'true' | '1' (latest 6 approved items for home page)
 *  - limit, offset
 */

require_once __DIR__ . '/../config/database.php';

initSession();
$currentUser = getCurrentUser();

$type       = trim($_GET['type'] ?? '');
$category   = trim($_GET['category'] ?? '');
$location   = trim($_GET['location'] ?? '');
$search     = trim($_GET['search'] ?? '');
$dateFrom   = trim($_GET['date_from'] ?? '');
$dateTo     = trim($_GET['date_to'] ?? '');
$mine       = isset($_GET['mine']) && in_array(strtolower($_GET['mine']), ['true', '1', 'yes'], true);
$recent     = isset($_GET['recent']) && in_array(strtolower($_GET['recent']), ['true', '1', 'yes'], true);
$status     = trim($_GET['status'] ?? '');
$limit      = isset($_GET['limit']) ? max(1, min(100, (int)$_GET['limit'])) : ($recent ? 6 : 50);
$offset     = isset($_GET['offset']) ? max(0, (int)$_GET['offset']) : 0;

$db = getDB();

$conditions = [];
$params = [];

if ($mine) {
    // Current user's posts
    if (!$currentUser) {
        sendJson(['success' => false, 'message' => 'Please log in to view your posts.'], 401);
    }
    $conditions[] = "i.user_id = :current_user_id";
    $params[':current_user_id'] = $currentUser['id'];

    if (!empty($status)) {
        $conditions[] = "i.status = :status";
        $params[':status'] = $status;
    }
} else {
    // Public portal view - show approved items, or optionally resolved items
    if (!empty($status)) {
        $conditions[] = "i.status = :status";
        $params[':status'] = $status;
    } else {
        $conditions[] = "i.status IN ('approved', 'claimed', 'resolved')";
    }
}

// Filter by type
if (!empty($type) && in_array($type, ['lost', 'found'], true)) {
    $conditions[] = "i.type = :type";
    $params[':type'] = $type;
}

// Filter by category
if (!empty($category) && $category !== 'All' && $category !== 'all') {
    $conditions[] = "i.category = :category";
    $params[':category'] = $category;
}

// Filter by location
if (!empty($location)) {
    $conditions[] = "i.location LIKE :location";
    $params[':location'] = '%' . $location . '%';
}

// Search keyword
if (!empty($search)) {
    $conditions[] = "(i.item_name LIKE :search1 OR i.description LIKE :search2 OR i.location LIKE :search3)";
    $params[':search1'] = '%' . $search . '%';
    $params[':search2'] = '%' . $search . '%';
    $params[':search3'] = '%' . $search . '%';
}

// Date filters
if (!empty($dateFrom) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateFrom)) {
    $conditions[] = "i.item_date >= :date_from";
    $params[':date_from'] = $dateFrom;
}
if (!empty($dateTo) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateTo)) {
    $conditions[] = "i.item_date <= :date_to";
    $params[':date_to'] = $dateTo;
}

$whereClause = !empty($conditions) ? 'WHERE ' . implode(' AND ', $conditions) : '';

// Count total matching items
$countSql = "SELECT COUNT(*) FROM items i $whereClause";
$countStmt = $db->prepare($countSql);
$countStmt->execute($params);
$totalCount = (int)$countStmt->fetchColumn();

// Fetch items
$sql = "
    SELECT 
        i.id,
        i.user_id,
        i.type,
        i.item_name,
        i.category,
        i.description,
        i.location,
        i.item_date,
        i.approx_time,
        i.image,
        i.additional_info,
        i.status,
        i.created_at,
        i.updated_at,
        u.name AS reporter_name,
        (SELECT COUNT(*) FROM claims c WHERE c.item_id = i.id) AS claims_count
    FROM items i
    JOIN users u ON i.user_id = u.id
    $whereClause
    ORDER BY i.created_at DESC
    LIMIT " . (int)$limit . " OFFSET " . (int)$offset;

$stmt = $db->prepare($sql);
$stmt->execute($params);
$items = $stmt->fetchAll();

// Add helper image url and ownership tag
foreach ($items as &$item) {
    if (!empty($item['image'])) {
        $item['image_url'] = '../backend/uploads/' . $item['image'];
    } else {
        $item['image_url'] = null;
    }

    $item['is_owner'] = ($currentUser && $currentUser['id'] == $item['user_id']);
}
unset($item);

sendJson([
    'success' => true,
    'total'   => $totalCount,
    'count'   => count($items),
    'items'   => $items
]);
