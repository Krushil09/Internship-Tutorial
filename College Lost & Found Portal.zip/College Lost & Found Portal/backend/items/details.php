<?php
/**
 * CampusFind - Item Details Endpoint
 * GET /backend/items/details.php?id=123
 */

require_once __DIR__ . '/../config/database.php';

initSession();
$currentUser = getCurrentUser();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    sendJson(['success' => false, 'message' => 'Invalid or missing Item ID.'], 400);
}

$db = getDB();

$stmt = $db->prepare("
    SELECT 
        i.*,
        u.name AS reporter_name,
        u.email AS reporter_email,
        u.phone AS reporter_phone
    FROM items i
    JOIN users u ON i.user_id = u.id
    WHERE i.id = ?
    LIMIT 1
");
$stmt->execute([$id]);
$item = $stmt->fetch();

if (!$item) {
    sendJson(['success' => false, 'message' => 'Item not found.'], 404);
}

$isOwner = $currentUser && ($currentUser['id'] == $item['user_id']);
$isAdmin = $currentUser && (($currentUser['role'] ?? '') === 'admin');

// If item is pending or rejected, only owner or admin can view
if (in_array($item['status'], ['pending', 'rejected']) && !$isOwner && !$isAdmin) {
    sendJson(['success' => false, 'message' => 'This item post is pending review or is not publicly available.'], 403);
}

// Check if current user has already submitted a claim on this item
$userHasClaimed = false;
$userClaim = null;
if ($currentUser && !$isOwner) {
    $claimCheck = $db->prepare("SELECT id, status, created_at, message FROM claims WHERE item_id = ? AND claimant_id = ? LIMIT 1");
    $claimCheck->execute([$id, $currentUser['id']]);
    $existingClaim = $claimCheck->fetch();
    if ($existingClaim) {
        $userHasClaimed = true;
        $userClaim = $existingClaim;
    }
}

// If owner or admin, fetch all claims on this item
$itemClaims = [];
if ($isOwner || $isAdmin) {
    $claimsStmt = $db->prepare("
        SELECT 
            c.*,
            u.name AS claimant_name,
            u.email AS claimant_email,
            u.phone AS claimant_phone
        FROM claims c
        JOIN users u ON c.claimant_id = u.id
        WHERE c.item_id = ?
        ORDER BY c.created_at DESC
    ");
    $claimsStmt->execute([$id]);
    $itemClaims = $claimsStmt->fetchAll();
}

// Mask reporter contact for public unless authorized
if (!$isOwner && !$isAdmin) {
    unset($item['reporter_email'], $item['reporter_phone']);
}

// Add image URL
$item['image_url'] = !empty($item['image']) ? '../backend/uploads/' . $item['image'] : null;

sendJson([
    'success'          => true,
    'item'             => $item,
    'is_owner'         => $isOwner,
    'is_admin'         => $isAdmin,
    'user_has_claimed' => $userHasClaimed,
    'user_claim'       => $userClaim,
    'claims'           => $itemClaims
]);
