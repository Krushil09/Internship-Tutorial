<?php
/**
 * CampusFind - Delete Item
 * POST or DELETE /backend/items/delete.php
 */

require_once __DIR__ . '/../config/database.php';

$currentUser = requireAuth();

$data = !empty($_POST) ? $_POST : getRequestData();
$id = isset($data['id']) ? (int)$data['id'] : (isset($_GET['id']) ? (int)$_GET['id'] : 0);

if ($id <= 0) {
    sendJson(['success' => false, 'message' => 'Valid Item ID is required.'], 400);
}

$db = getDB();

// Fetch item
$stmt = $db->prepare("SELECT user_id, image, item_name FROM items WHERE id = ? LIMIT 1");
$stmt->execute([$id]);
$item = $stmt->fetch();

if (!$item) {
    sendJson(['success' => false, 'message' => 'Item not found.'], 404);
}

$isOwner = ((int)$item['user_id'] === (int)$currentUser['id']);
$isAdmin = (($currentUser['role'] ?? '') === 'admin');

if (!$isOwner && !$isAdmin) {
    sendJson(['success' => false, 'message' => 'Unauthorized. You can only delete your own posts.'], 403);
}

// Delete image file from disk if present
if (!empty($item['image'])) {
    $imagePath = UPLOADS_DIR . DIRECTORY_SEPARATOR . $item['image'];
    if (file_exists($imagePath)) {
        @unlink($imagePath);
    }
}

// Delete item record (cascading deletes claims & notifications)
$deleteStmt = $db->prepare("DELETE FROM items WHERE id = ?");
$deleteStmt->execute([$id]);

sendJson([
    'success' => true,
    'message' => 'Item post "' . htmlspecialchars($item['item_name']) . '" deleted successfully.'
]);
