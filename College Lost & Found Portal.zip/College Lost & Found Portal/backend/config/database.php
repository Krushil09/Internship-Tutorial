<?php
/**
 * CampusFind - College Lost & Found Portal
 * Backend Database Connection & Helper Utilities
 */

// Enable error reporting during development, display off to keep JSON clean
error_reporting(E_ALL);
ini_set('display_errors', '0');

// Database Credentials
define('DB_HOST', 'localhost');
define('DB_NAME', 'college_lost_found');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// Directory Constants
define('BACKEND_DIR', dirname(__DIR__));
define('UPLOADS_DIR', BACKEND_DIR . DIRECTORY_SEPARATOR . 'uploads');

/**
 * Returns the PDO database connection singleton
 */
function getDB(): PDO {
    static $pdo = null;

    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => true, // Enable prepare emulation to allow parameter reuse safely
        ];

        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            sendJson([
                'success' => false,
                'message' => 'Database connection failed: ' . $e->getMessage()
            ], 500);
        }
    }

    return $pdo;
}

/**
 * Starts session securely with persistent cookie policy
 */
function initSession(): void {
    if (session_status() === PHP_SESSION_NONE) {
        // Set garbage collection lifetime to 7 days
        ini_set('session.gc_maxlifetime', '604800');
        
        $isSecure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
        session_set_cookie_params([
            'lifetime' => 604800, // 7 days
            'path'     => '/',
            'domain'   => '',
            'secure'   => $isSecure,
            'httponly' => true,
            'samesite' => 'Lax'
        ]);
        session_start();
    }
}

/**
 * Sends a clean JSON response and exits
 */
function sendJson(array $data, int $httpCode = 200): void {
    http_response_code($httpCode);
    header('Content-Type: application/json; charset=UTF-8');
    
    // Support credentials with explicit Origin (do NOT use wildcard '*' with credentials)
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    if (!empty($origin)) {
        header("Access-Control-Allow-Origin: $origin");
        header('Access-Control-Allow-Credentials: true');
    }
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
    
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        exit(0);
    }
    
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/**
 * Parses incoming JSON or POST request data
 */
function getRequestData(): array {
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
    
    if (stripos($contentType, 'application/json') !== false) {
        $raw = file_get_contents('php://input');
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }

    // Default to $_POST and trim all string inputs
    $cleaned = [];
    foreach ($_POST as $key => $val) {
        $cleaned[$key] = is_string($val) ? trim($val) : $val;
    }
    return $cleaned;
}

/**
 * Get current authenticated user session or null
 */
function getCurrentUser(): ?array {
    initSession();
    return $_SESSION['user'] ?? null;
}

/**
 * Enforce authenticated student or admin
 */
function requireAuth(): array {
    $user = getCurrentUser();
    if (!$user) {
        sendJson([
            'success' => false,
            'message' => 'Authentication required. Please log in.',
            'redirect' => 'login.html'
        ], 401);
    }
    return $user;
}

/**
 * Enforce administrator access
 */
function requireAdmin(): array {
    $user = requireAuth();
    if (($user['role'] ?? '') !== 'admin') {
        sendJson([
            'success' => false,
            'message' => 'Access denied. Administrator privileges required.'
        ], 403);
    }
    return $user;
}

/**
 * Create a user notification
 */
function addNotification(PDO $db, int $userId, string $title, string $message): bool {
    try {
        $stmt = $db->prepare("INSERT INTO notifications (user_id, title, message, is_read, created_at) VALUES (?, ?, ?, 0, NOW())");
        return $stmt->execute([$userId, $title, $message]);
    } catch (Exception $e) {
        return false;
    }
}
