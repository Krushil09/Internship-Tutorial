<?php
/**
 * CampusFind - Update Claim Status (Accept / Reject)
 * POST /backend/claims/update.php
 */

require_once __DIR__ . '/../config/database.php';

$currentUser = requireAuth();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJson(['success' => false, 'message' => 'Invalid request method. Expected POST.'], 405);
}

$data = getRequestData();
$claimId = isset($data['claim_id']) ? (int)$data['claim_id'] : (isset($data['id']) ? (int)$data['id'] : 0);
$status  = strtolower(trim($data['status'] ?? ''));

if ($claimId <= 0) {
    sendJson(['success' => false, 'message' => 'Valid Claim ID is required.'], 400);
}

if (!in_array($status, ['accepted', 'rejected'], true)) {
    sendJson(['success' => false, 'message' => 'Status must be "accepted" or "rejected".'], 422);
}

$db = getDB();

// Fetch claim with item info
$stmt = $db->prepare("
    SELECT 
        c.id, c.item_id, c.claimant_id, c.status AS current_status,
        i.user_id AS item_owner_id, i.item_name
    FROM claims c
    JOIN items i ON c.item_id = i.id
    WHERE c.id = ?
    LIMIT 1
");
$stmt->execute([$claimId]);
$claim = $stmt->fetch();

if (!$claim) {
    sendJson(['success' => false, 'message' => 'Claim not found.'], 404);
}

$isOwner = ((int)$claim['item_owner_id'] === (int)$currentUser['id']);
$isAdmin = (($currentUser['role'] ?? '') === 'admin');

if (!$isOwner && !$isAdmin) {
    sendJson(['success' => false, 'message' => 'Unauthorized. Only the item reporter or an admin can review this claim.'], 403);
}

try {
    $db->beginTransaction();

    // Update claim status
    $upStmt = $db->prepare("UPDATE claims SET status = ?, updated_at = NOW() WHERE id = ?");
    $upStmt->execute([$status, $claimId]);

    if ($status === 'accepted') {
        // Mark item as claimed/resolved
        $itemUpStmt = $db->prepare("UPDATE items SET status = 'claimed', updated_at = NOW() WHERE id = ?");
        $itemUpStmt->execute([$claim['item_id']]);

        // Notify claimant
        addNotification(
            $db,
            (int)$claim['claimant_id'],
            'Claim Accepted!',
            "Your claim for \"{$claim['item_name']}\" was accepted! Please review contact details in My Claims to coordinate pickup."
        );
    } else {
        // Notify claimant of rejection
        addNotification(
            $db,
            (int)$claim['claimant_id'],
            'Claim Update',
            "Your claim for \"{$claim['item_name']}\" was reviewed and marked as rejected."
        );
    }

    $db->commit();

    sendJson([
        'success' => true,
        'message' => 'Claim status has been updated to ' . ucfirst($status) . '.'
    ]);

} catch (Exception $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    sendJson(['success' => false, 'message' => 'Failed to update claim: ' . $e->getMessage()], 500);
}
