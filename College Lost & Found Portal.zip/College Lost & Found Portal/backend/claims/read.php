<?php
/**
 * CampusFind - Read Claims
 * GET /backend/claims/read.php
 * Query Params:
 *  - mine: 'true' (claims submitted by current user)
 *  - received: 'true' (claims submitted on items owned by current user)
 *  - item_id: int (claims on a specific item)
 */

require_once __DIR__ . '/../config/database.php';

$currentUser = requireAuth();

$mine     = isset($_GET['mine']) && in_array(strtolower($_GET['mine']), ['true', '1', 'yes'], true);
$received = isset($_GET['received']) && in_array(strtolower($_GET['received']), ['true', '1', 'yes'], true);
$itemId   = isset($_GET['item_id']) ? (int)$_GET['item_id'] : 0;

$db = getDB();

if ($mine) {
    // Claims submitted by current user
    $stmt = $db->prepare("
        SELECT 
            c.id,
            c.item_id,
            c.message,
            c.contact_info,
            c.status,
            c.created_at,
            c.updated_at,
            i.item_name,
            i.type AS item_type,
            i.category AS item_category,
            i.location AS item_location,
            i.item_date,
            i.image AS item_image,
            i.status AS item_status,
            u.name AS reporter_name
        FROM claims c
        JOIN items i ON c.item_id = i.id
        JOIN users u ON i.user_id = u.id
        WHERE c.claimant_id = ?
        ORDER BY c.created_at DESC
    ");
    $stmt->execute([$currentUser['id']]);
    $claims = $stmt->fetchAll();

    foreach ($claims as &$claim) {
        $claim['item_image_url'] = !empty($claim['item_image']) ? '../backend/uploads/' . $claim['item_image'] : null;
    }
    unset($claim);

    sendJson([
        'success' => true,
        'count'   => count($claims),
        'claims'  => $claims
    ]);
}

if ($received) {
    // Claims submitted by others on current user's items
    $stmt = $db->prepare("
        SELECT 
            c.id,
            c.item_id,
            c.message,
            c.contact_info,
            c.status,
            c.created_at,
            c.updated_at,
            i.item_name,
            i.type AS item_type,
            i.status AS item_status,
            u.name AS claimant_name,
            u.email AS claimant_email,
            u.phone AS claimant_phone
        FROM claims c
        JOIN items i ON c.item_id = i.id
        JOIN users u ON c.claimant_id = u.id
        WHERE i.user_id = ?
        ORDER BY c.created_at DESC
    ");
    $stmt->execute([$currentUser['id']]);
    $claims = $stmt->fetchAll();

    sendJson([
        'success' => true,
        'count'   => count($claims),
        'claims'  => $claims
    ]);
}

if ($itemId > 0) {
    // Claims on specific item - check permission (must be item owner or admin)
    $chkStmt = $db->prepare("SELECT user_id FROM items WHERE id = ? LIMIT 1");
    $chkStmt->execute([$itemId]);
    $itemOwnerId = $chkStmt->fetchColumn();

    $isAdmin = (($currentUser['role'] ?? '') === 'admin');
    $isOwner = ((int)$itemOwnerId === (int)$currentUser['id']);

    if (!$isOwner && !$isAdmin) {
        sendJson(['success' => false, 'message' => 'Unauthorized to view claims for this item.'], 403);
    }

    $stmt = $db->prepare("
        SELECT 
            c.*,
            u.name AS claimant_name,
            u.email AS claimant_email,
            u.phone AS claimant_phone
        FROM claims c
        JOIN users u ON c.claimant_id = u.id
        WHERE c.item_id = ?
        ORDER BY c.created_at DESC
    ");
    $stmt->execute([$itemId]);
    $claims = $stmt->fetchAll();

    sendJson([
        'success' => true,
        'count'   => count($claims),
        'claims'  => $claims
    ]);
}

sendJson(['success' => false, 'message' => 'Invalid query parameters. Specify mine=true, received=true, or item_id.'], 400);
