<?php
/**
 * CampusFind - Submit Item Claim
 * POST /backend/claims/create.php
 */

require_once __DIR__ . '/../config/database.php';

$currentUser = requireAuth();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJson(['success' => false, 'message' => 'Invalid request method. Expected POST.'], 405);
}

$data = getRequestData();

$itemId      = isset($data['item_id']) ? (int)$data['item_id'] : 0;
$message     = trim($data['message'] ?? '');
$contactInfo = trim($data['contact_info'] ?? '');

if ($itemId <= 0) {
    sendJson(['success' => false, 'message' => 'Valid Item ID is required.'], 400);
}

if (empty($message)) {
    sendJson(['success' => false, 'message' => 'Please provide the reason / identifying details for your claim.'], 422);
}

if (empty($contactInfo)) {
    sendJson(['success' => false, 'message' => 'Please provide your contact information.'], 422);
}

$db = getDB();

// Fetch item details
$itemStmt = $db->prepare("SELECT id, user_id, item_name, status FROM items WHERE id = ? LIMIT 1");
$itemStmt->execute([$itemId]);
$item = $itemStmt->fetch();

if (!$item) {
    sendJson(['success' => false, 'message' => 'Item not found.'], 404);
}

// User cannot claim their own post
if ((int)$item['user_id'] === (int)$currentUser['id']) {
    sendJson(['success' => false, 'message' => 'You cannot submit a claim on an item you reported yourself.'], 400);
}

// Check for existing pending claim by this user
$claimCheck = $db->prepare("SELECT id FROM claims WHERE item_id = ? AND claimant_id = ? AND status = 'pending' LIMIT 1");
$claimCheck->execute([$itemId, $currentUser['id']]);
if ($claimCheck->fetch()) {
    sendJson(['success' => false, 'message' => 'You have already submitted a pending claim on this item. Please await the owner or admin response.'], 409);
}

try {
    $insertStmt = $db->prepare("
        INSERT INTO claims (item_id, claimant_id, message, contact_info, status, created_at)
        VALUES (?, ?, ?, ?, 'pending', NOW())
    ");
    $insertStmt->execute([$itemId, $currentUser['id'], $message, $contactInfo]);
    $claimId = (int)$db->lastInsertId();

    // Notify item reporter
    $notifTitle = 'New Claim Received';
    $notifMessage = "A student has submitted an ownership claim on your item \"{$item['item_name']}\". Review it in your claims dashboard.";
    addNotification($db, (int)$item['user_id'], $notifTitle, $notifMessage);

    sendJson([
        'success'  => true,
        'message'  => 'Your claim has been submitted successfully! The reporter and administrators will review your identifying proof.',
        'claim_id' => $claimId
    ], 201);

} catch (Exception $e) {
    sendJson(['success' => false, 'message' => 'Failed to submit claim. Please try again later.'], 500);
}
