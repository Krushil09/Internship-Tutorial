-- CampusFind - College Lost & Found Portal
-- MySQL Database Schema and Seed Data

SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS `college_lost_found` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `college_lost_found`;

-- --------------------------------------------------------
-- Table structure for table `users`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(120) NOT NULL UNIQUE,
  `phone` VARCHAR(25) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('student', 'admin') NOT NULL DEFAULT 'student',
  `status` ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_users_email` (`email`),
  INDEX `idx_users_role` (`role`),
  INDEX `idx_users_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `items`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `items`;
CREATE TABLE `items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `type` ENUM('lost', 'found') NOT NULL,
  `item_name` VARCHAR(150) NOT NULL,
  `category` VARCHAR(50) NOT NULL,
  `description` TEXT NOT NULL,
  `location` VARCHAR(150) NOT NULL,
  `item_date` DATE NOT NULL,
  `approx_time` VARCHAR(50) DEFAULT NULL,
  `image` VARCHAR(255) DEFAULT NULL,
  `additional_info` TEXT DEFAULT NULL,
  `status` ENUM('pending', 'approved', 'claimed', 'resolved', 'rejected') NOT NULL DEFAULT 'pending',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_items_user` (`user_id`),
  INDEX `idx_items_type` (`type`),
  INDEX `idx_items_status` (`status`),
  INDEX `idx_items_category` (`category`),
  INDEX `idx_items_date` (`item_date`),
  INDEX `idx_items_location` (`location`),
  CONSTRAINT `fk_items_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `claims`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `claims`;
CREATE TABLE `claims` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `item_id` INT NOT NULL,
  `claimant_id` INT NOT NULL,
  `message` TEXT NOT NULL,
  `contact_info` VARCHAR(150) NOT NULL,
  `status` ENUM('pending', 'accepted', 'rejected') NOT NULL DEFAULT 'pending',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_claims_item` (`item_id`),
  INDEX `idx_claims_claimant` (`claimant_id`),
  INDEX `idx_claims_status` (`status`),
  CONSTRAINT `fk_claims_item` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_claims_claimant` FOREIGN KEY (`claimant_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `notifications`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `title` VARCHAR(150) NOT NULL,
  `message` TEXT NOT NULL,
  `is_read` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_notifications_user` (`user_id`),
  INDEX `idx_notifications_unread` (`user_id`, `is_read`),
  CONSTRAINT `fk_notifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- --------------------------------------------------------
-- Seed Data for Testing & Demonstration
-- Passwords:
-- Admin: admin@campus.edu -> admin123
-- Students: alex.rivera@student.college.edu, emily.chen@student.college.edu, marcus.bell@student.college.edu -> password123
-- --------------------------------------------------------

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `password`, `role`, `status`, `created_at`) VALUES
(1, 'Campus Administrator', 'admin@campus.edu', '+1 (555) 019-2834', '$2y$10$MD.CiCak5ljZiFewErfh/O9V6wMZ/wlyW0XuJ.E7puZpg4kpnDZTC', 'admin', 'active', NOW()),
(2, 'Alex Rivera', 'alex.rivera@student.college.edu', '+1 (555) 234-5678', '$2y$10$bD.SdX53r7h9qbEHuvdfLe/SqXCH8daXmRdBbWZ84VdqJb32U3aOm', 'student', 'active', NOW()),
(3, 'Emily Chen', 'emily.chen@student.college.edu', '+1 (555) 345-6789', '$2y$10$bD.SdX53r7h9qbEHuvdfLe/SqXCH8daXmRdBbWZ84VdqJb32U3aOm', 'student', 'active', NOW()),
(4, 'Marcus Bell', 'marcus.bell@student.college.edu', '+1 (555) 456-7890', '$2y$10$bD.SdX53r7h9qbEHuvdfLe/SqXCH8daXmRdBbWZ84VdqJb32U3aOm', 'student', 'active', NOW());

INSERT INTO `items` (`id`, `user_id`, `type`, `item_name`, `category`, `description`, `location`, `item_date`, `approx_time`, `image`, `additional_info`, `status`, `created_at`) VALUES
(1, 2, 'lost', 'Student ID Card (Alex Rivera)', 'ID Cards', 'Standard university plastic smart ID card with navy lanyard badge clip. Registration #2024-CS-042.', 'Central Library', DATE_SUB(CURDATE(), INTERVAL 2 DAY), '2:30 PM', NULL, 'Last seen at the 2nd floor silent study carrels near Computer Science section.', 'approved', NOW()),
(2, 3, 'found', 'Black Leather Trifold Wallet', 'Wallets', 'Found a men\'s black leather trifold wallet containing some cash and a subway pass. Kept safely in hand, no student card inside.', 'Main Cafeteria / Canteen', DATE_SUB(CURDATE(), INTERVAL 1 DAY), '1:15 PM', NULL, 'Found on a corner booth table near the smoothie stall.', 'approved', NOW()),
(3, 4, 'lost', 'Apple MacBook USB-C 67W Charger & Cable', 'Electronics', 'White Apple genuine 67W power adapter with 2-meter braided USB-C charging cord. Has a small teal sticker on the brick.', 'Computer Science Lab (Block A)', DATE_SUB(CURDATE(), INTERVAL 3 DAY), '4:45 PM', NULL, 'Left plugged into wall outlet bench 4.', 'approved', NOW()),
(4, 2, 'found', 'Set of Keys with Red University Lanyard', 'Keys', 'Ring with two brass door keys, one small locker key, and a red campus gym tag numbered #118.', 'Sports Ground / Gymnasium', DATE_SUB(CURDATE(), INTERVAL 1 DAY), '6:00 PM', NULL, 'Found sitting on the spectator bleachers.', 'approved', NOW()),
(5, 3, 'lost', 'Texas Instruments TI-84 Plus CE Calculator', 'Electronics', 'Color screen graphing calculator in dark blue casing. Has owner initials "E.C." faintly scratched on battery cover back.', 'Science Complex (Block C)', DATE_SUB(CURDATE(), INTERVAL 4 DAY), '11:00 AM', NULL, 'Lost after Chemistry 201 lecture in Room 302.', 'approved', NOW()),
(6, 4, 'found', 'Navy Blue North Face Backpack', 'Bags', 'Found a dark blue everyday campus backpack with water bottle in side mesh. Contains lecture notebooks for Mechanical Engineering.', 'Student Center / Quad', CURDATE(), '10:15 AM', NULL, 'Deposited temporarily at the campus student union front desk.', 'pending', NOW()),
(7, 2, 'lost', 'Prescription Reading Glasses in Brown Case', 'Accessories', 'Tortoiseshell frame reading glasses inside a hard matte brown protective case.', 'Auditorium / Seminar Hall', DATE_SUB(CURDATE(), INTERVAL 5 DAY), '3:00 PM', NULL, 'Dropped during the orientation guest speaker seminar.', 'resolved', NOW());

INSERT INTO `claims` (`id`, `item_id`, `claimant_id`, `message`, `contact_info`, `status`, `created_at`) VALUES
(1, 2, 4, 'Hi Emily, I believe this is my wallet. It has my local transit card and an emergency $20 note in the inner zipper slot.', 'marcus.bell@student.college.edu / (555) 456-7890', 'pending', NOW()),
(2, 7, 2, 'This was verified and returned to me by the campus security officer on duty. Thank you!', 'alex.rivera@student.college.edu', 'accepted', DATE_SUB(NOW(), INTERVAL 1 DAY));

INSERT INTO `notifications` (`id`, `user_id`, `title`, `message`, `is_read`, `created_at`) VALUES
(1, 2, 'Post Approved', 'Your lost report for "Student ID Card (Alex Rivera)" has been reviewed and approved by the campus administrator.', 1, NOW()),
(2, 3, 'New Claim Received', 'A student has submitted an ownership claim on your found item: "Black Leather Trifold Wallet". Please review the details in My Claims.', 0, NOW()),
(3, 4, 'Post Approved', 'Your lost report for "Apple MacBook USB-C 67W Charger" is now active on the public portal.', 0, NOW());
