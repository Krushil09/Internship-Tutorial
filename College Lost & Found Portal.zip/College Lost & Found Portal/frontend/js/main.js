/**
 * CampusFind - College Lost & Found Portal
 * Main Utility & Navigation Script
 * Pure Vanilla JavaScript
 */

// Determine API base path dynamically relative to current page location
const API_BASE = (function () {
  const path = window.location.pathname;
  if (path.includes('/frontend/admin/')) {
    return '../../backend';
  } else if (path.includes('/frontend/')) {
    return '../backend';
  } else {
    return 'backend';
  }
})();

/**
 * Universal API Fetch with session credentials
 */
async function apiFetch(endpoint, options = {}) {
  const opts = {
    credentials: 'same-origin',
    ...options
  };
  opts.headers = {
    ...(options.headers || {})
  };
  const url = endpoint.startsWith('http') ? endpoint : `${API_BASE}${endpoint}`;
  return fetch(url, opts);
}

/**
 * Toast Notification System
 */
function showToast(message, type = 'info', duration = 4000) {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;

  const iconMap = {
    success: '✓',
    error: '✕',
    warning: '⚠',
    info: 'ℹ'
  };

  toast.innerHTML = `
    <span style="font-weight:700; font-size:1.1rem; line-height:1;">${iconMap[type] || 'ℹ'}</span>
    <div style="flex:1;">${escapeHtml(message)}</div>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

/**
 * HTML Escaping utility to prevent XSS
 */
function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/**
 * Format Date to readable academic format
 */
function formatDate(dateStr) {
  if (!dateStr) return 'N/A';
  const parts = dateStr.split('-');
  if (parts.length === 3) {
    const d = new Date(parts[0], parts[1] - 1, parts[2]);
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  }
  return dateStr;
}

/**
 * SVG Placeholder Generator for Items with No Image
 */
function getItemPlaceholderSvg(category, type) {
  const bgColor = (type === 'lost') ? '#FDEDED' : '#E8F0FE';
  const textColor = (type === 'lost') ? '#C62828' : '#1E3A5F';
  const initial = category ? category.charAt(0).toUpperCase() : '?';

  return `
    <div style="width:100%; height:100%; background:${bgColor}; display:flex; flex-direction:column; align-items:center; justify-content:center; color:${textColor};">
      <div style="width:56px; height:56px; border-radius:50%; background:rgba(255,255,255,0.85); display:flex; align-items:center; justify-content:center; font-weight:700; font-size:1.5rem; margin-bottom:8px; border:1px solid rgba(0,0,0,0.06);">
        ${initial}
      </div>
      <span style="font-size:0.75rem; font-weight:600; text-transform:uppercase; letter-spacing:0.05em;">${escapeHtml(category || 'Item')}</span>
    </div>
  `;
}

/**
 * Check Session & Update Navigation Dynamically
 * Persists session and updates UI without interrupting user navigation
 */
async function checkAuthAndUpdateNav() {
  const isInsideAdmin = window.location.pathname.includes('/admin/');
  const currentPath = window.location.pathname;
  const isLoginPage = currentPath.endsWith('login.html') || currentPath.endsWith('register.html');
  
  // Protected student pages that require active student session
  const isProtectedStudentPage = (
    currentPath.endsWith('dashboard.html') && !isInsideAdmin ||
    currentPath.endsWith('my-posts.html') ||
    currentPath.endsWith('my-claims.html') ||
    currentPath.endsWith('profile.html') ||
    currentPath.endsWith('report-lost.html') ||
    currentPath.endsWith('report-found.html')
  );

  try {
    const res = await apiFetch('/auth/session.php');
    if (!res.ok) {
      console.warn('Session endpoint returned status', res.status);
      return;
    }
    const data = await res.json();

    const authContainer = document.getElementById('nav-auth-container');
    const mobileAuthContainer = document.getElementById('mobile-auth-container');
    const basePath = isInsideAdmin ? '../' : '';

    if (data.logged_in && data.user) {
      window.currentUser = data.user;

      // If user is admin on student pages or admin on login page
      if (data.user.role === 'admin') {
        if (isLoginPage) {
          window.location.href = isInsideAdmin ? 'dashboard.html' : 'admin/dashboard.html';
          return;
        }

        // On public pages, render link to Admin Console
        if (authContainer) {
          authContainer.innerHTML = `
            <a href="${basePath}admin/dashboard.html" class="nav-link" style="color:var(--primary); font-weight:700;">Admin Console</a>
            <button id="logout-btn" class="btn btn-outline btn-sm">Logout</button>
          `;
        }

        if (mobileAuthContainer) {
          mobileAuthContainer.innerHTML = `
            <a href="${basePath}admin/dashboard.html" style="font-weight:700;">Admin Console</a>
            <a href="#" id="mobile-logout-btn" style="color:var(--danger);">Logout (${escapeHtml(data.user.name)})</a>
          `;
        }

      } else {
        // Logged in as student
        if (isLoginPage) {
          window.location.href = isInsideAdmin ? '../dashboard.html' : 'dashboard.html';
          return;
        }

        const unreadCount = data.stats?.unread_notifications || 0;
        const badgeHtml = unreadCount > 0 ? `<span style="background:var(--danger); color:#fff; font-size:11px; padding:2px 6px; border-radius:10px; margin-left:4px;">${unreadCount}</span>` : '';

        const userNavHtml = `
          <a href="${basePath}dashboard.html" class="nav-link">Dashboard</a>
          <a href="${basePath}my-posts.html" class="nav-link">My Posts</a>
          <a href="${basePath}my-claims.html" class="nav-link">My Claims</a>
          <a href="${basePath}profile.html" class="btn btn-secondary btn-sm" style="display:flex; align-items:center;">
            👤 ${escapeHtml(data.user.name.split(' ')[0])} ${badgeHtml}
          </a>
          <button id="logout-btn" class="btn btn-outline btn-sm">Logout</button>
        `;

        if (authContainer) authContainer.innerHTML = userNavHtml;

        if (mobileAuthContainer) {
          mobileAuthContainer.innerHTML = `
            <a href="${basePath}dashboard.html">Dashboard</a>
            <a href="${basePath}my-posts.html">My Posts</a>
            <a href="${basePath}my-claims.html">My Claims</a>
            <a href="${basePath}profile.html">Profile & Notifications (${unreadCount})</a>
            <a href="#" id="mobile-logout-btn" style="color:var(--danger);">Logout (${escapeHtml(data.user.name)})</a>
          `;
        }
      }

      // Attach logout handlers
      const logoutBtn = document.getElementById('logout-btn');
      if (logoutBtn) logoutBtn.addEventListener('click', handleLogout);
      const mobileLogoutBtn = document.getElementById('mobile-logout-btn');
      if (mobileLogoutBtn) mobileLogoutBtn.addEventListener('click', handleLogout);

    } else {
      window.currentUser = null;

      // If user is unauthenticated on protected student page, redirect to login
      if (isProtectedStudentPage) {
        window.location.href = 'login.html';
        return;
      }

      // Public guest navigation
      const guestNavHtml = `
        <a href="${basePath}login.html" class="btn btn-secondary btn-sm">Login</a>
        <a href="${basePath}register.html" class="btn btn-primary btn-sm">Register</a>
      `;

      if (authContainer) authContainer.innerHTML = guestNavHtml;

      if (mobileAuthContainer) {
        mobileAuthContainer.innerHTML = `
          <a href="${basePath}login.html">Login</a>
          <a href="${basePath}register.html">Register Account</a>
        `;
      }
    }
  } catch (err) {
    console.error('Session check error:', err);
  }
}

/**
 * Handle Manual Logout
 * Completely terminates session and redirects to appropriate portal login
 */
async function handleLogout(e) {
  if (e) {
    e.preventDefault();
    e.stopPropagation();
  }
  
  const isInsideAdmin = window.location.pathname.includes('/admin/');
  const portal = isInsideAdmin ? 'admin' : 'student';

  try {
    const res = await apiFetch(`/auth/logout.php?portal=${portal}`, { method: 'POST' });
    const data = await res.json();
    showToast(data.message || 'Logged out successfully.', 'info');
    setTimeout(() => {
      window.location.href = isInsideAdmin ? 'login.html' : 'login.html';
    }, 400);
  } catch (err) {
    showToast('Logged out.', 'info');
    setTimeout(() => {
      window.location.href = isInsideAdmin ? 'login.html' : 'login.html';
    }, 400);
  }
}

/**
 * Password Visibility Toggle
 */
function initPasswordToggles() {
  document.querySelectorAll('.password-toggle-btn').forEach(btn => {
    btn.addEventListener('click', function () {
      const input = this.parentElement.querySelector('input');
      if (!input) return;
      if (input.type === 'password') {
        input.type = 'text';
        this.textContent = 'Hide';
      } else {
        input.type = 'password';
        this.textContent = 'Show';
      }
    });
  });
}

/**
 * Character Counter Initializer
 */
function initCharCounters() {
  document.querySelectorAll('[data-char-count]').forEach(input => {
    const max = parseInt(input.getAttribute('maxlength') || '500', 10);
    const targetId = input.getAttribute('data-char-count');
    const counterDisplay = document.getElementById(targetId);
    if (!counterDisplay) return;

    function update() {
      const remaining = max - input.value.length;
      counterDisplay.textContent = `${input.value.length} / ${max}`;
    }

    input.addEventListener('input', update);
    update();
  });
}

/**
 * Image Upload Preview Handler
 */
function initImageUploadPreview(inputId, previewBoxId, previewImgId, removeBtnId) {
  const input = document.getElementById(inputId);
  const previewBox = document.getElementById(previewBoxId);
  const previewImg = document.getElementById(previewImgId);
  const removeBtn = document.getElementById(removeBtnId);

  if (!input || !previewBox || !previewImg) return;

  input.addEventListener('change', function () {
    const file = this.files[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        showToast('Image file size must be less than 5MB.', 'error');
        this.value = '';
        previewBox.style.display = 'none';
        return;
      }
      const reader = new FileReader();
      reader.onload = function (e) {
        previewImg.src = e.target.result;
        previewBox.style.display = 'block';
      };
      reader.readAsDataURL(file);
    }
  });

  if (removeBtn) {
    removeBtn.addEventListener('click', function (e) {
      e.preventDefault();
      input.value = '';
      previewImg.src = '';
      previewBox.style.display = 'none';
    });
  }
}

/**
 * Generic Modal Controls
 */
function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.remove('open');
    document.body.style.overflow = '';
  }
}

/**
 * Mobile Navigation Toggle
 */
function initMobileNav() {
  const btn = document.getElementById('hamburger-toggle');
  const menu = document.getElementById('mobile-nav-menu');
  if (btn && menu) {
    btn.addEventListener('click', () => {
      menu.classList.toggle('open');
    });
  }
}

// Global DOM Ready Initialization
document.addEventListener('DOMContentLoaded', () => {
  initMobileNav();
  checkAuthAndUpdateNav();
  initPasswordToggles();
  initCharCounters();

  // Attach logout handler if #logout-btn already exists in static DOM (e.g. admin pages)
  const staticLogoutBtn = document.getElementById('logout-btn');
  if (staticLogoutBtn) {
    staticLogoutBtn.addEventListener('click', handleLogout);
  }

  // Close modals on overlay backdrop click
  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', function (e) {
      if (e.target === this) {
        this.classList.remove('open');
        document.body.style.overflow = '';
      }
    });
  });

  // Modal close buttons
  document.querySelectorAll('.modal-close-btn, [data-modal-close]').forEach(btn => {
    btn.addEventListener('click', function () {
      const modal = this.closest('.modal-overlay');
      if (modal) {
        modal.classList.remove('open');
        document.body.style.overflow = '';
      }
    });
  });
});
