/**
 * CampusFind - College Lost & Found Portal
 * Claims Management Script
 * Pure Vanilla JavaScript
 */

document.addEventListener('DOMContentLoaded', () => {
  // 1. Submit Claim Form Handler
  const claimForm = document.getElementById('claim-form');
  if (claimForm) {
    claimForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const submitBtn = claimForm.querySelector('button[type="submit"]');
      const itemId = document.getElementById('claim-item-id').value;
      const message = document.getElementById('claim-message').value.trim();
      const contactInfo = document.getElementById('claim-contact').value.trim();

      if (!message || !contactInfo) {
        showToast('Please provide your claim explanation and contact details.', 'warning');
        return;
      }

      submitBtn.disabled = true;
      submitBtn.textContent = 'Submitting Claim...';

      try {
        const res = await apiFetch('/claims/create.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            item_id: itemId,
            message: message,
            contact_info: contactInfo
          })
        });
        const data = await res.json();

        if (data.success) {
          showToast(data.message || 'Claim submitted successfully!', 'success');
          closeModal('claim-modal');
          // Reload page to reflect claim state
          setTimeout(() => window.location.reload(), 1000);
        } else {
          showToast(data.message || 'Could not submit claim.', 'error');
          submitBtn.disabled = false;
          submitBtn.textContent = 'Submit Claim';
        }
      } catch (err) {
        showToast('Server error while submitting claim.', 'error');
        submitBtn.disabled = false;
        submitBtn.textContent = 'Submit Claim';
      }
    });
  }

  // 2. My Claims Page: Claims submitted by me
  const myClaimsContainer = document.getElementById('my-claims-container');
  if (myClaimsContainer) {
    loadMySubmittedClaims(myClaimsContainer);
  }

  // 3. Claims Received on My Posts
  const receivedClaimsContainer = document.getElementById('received-claims-container');
  if (receivedClaimsContainer) {
    loadReceivedClaims(receivedClaimsContainer);
  }
});

/**
 * Load claims made by current student
 */
async function loadMySubmittedClaims(container) {
  try {
    container.innerHTML = '<div style="text-align:center; padding:3rem;"><div class="loading-spinner"></div><p style="margin-top:0.5rem; color:var(--text-muted);">Loading your submitted claims...</p></div>';
    const res = await apiFetch('/claims/read.php?mine=true');
    const data = await res.json();

    if (!data.success || !data.claims || data.claims.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">🏷️</div>
          <h3 class="empty-state-title">No Claims Submitted</h3>
          <p class="empty-state-text">You haven't claimed any found items yet. If you see something that belongs to you, click "I Think This Is Mine" on the item page.</p>
          <a href="found-items.html" class="btn btn-primary btn-sm">Browse Found Items</a>
        </div>
      `;
      return;
    }

    const rows = data.claims.map(claim => `
      <tr>
        <td>
          <div style="display:flex; align-items:center; gap:0.75rem;">
            <div style="width:44px; height:44px; border-radius:var(--radius-sm); overflow:hidden; background:#eee; flex-shrink:0;">
              ${claim.item_image_url ? `<img src="${escapeHtml(claim.item_image_url)}" style="width:100%; height:100%; object-fit:cover;">` : getItemPlaceholderSvg(claim.item_category, claim.item_type)}
            </div>
            <div>
              <a href="item-details.html?id=${claim.item_id}" style="font-weight:600; color:var(--primary);">${escapeHtml(claim.item_name)}</a>
              <div style="font-size:0.75rem; color:var(--text-muted);">${escapeHtml(claim.item_category)} • Found at ${escapeHtml(claim.item_location)}</div>
            </div>
          </div>
        </td>
        <td>${formatDate(claim.created_at?.split(' ')[0])}</td>
        <td>
          <span class="badge badge-${escapeHtml(claim.status)}">${escapeHtml(claim.status)}</span>
        </td>
        <td>
          <p style="font-size:0.85rem; color:var(--text-main); margin:0;">${escapeHtml(claim.message)}</p>
          <span style="font-size:0.75rem; color:var(--text-muted);">Contact: ${escapeHtml(claim.contact_info)}</span>
        </td>
        <td>
          <a href="item-details.html?id=${claim.item_id}" class="btn btn-outline btn-sm">View Item</a>
        </td>
      </tr>
    `).join('');

    container.innerHTML = `
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Item</th>
              <th>Claim Date</th>
              <th>Status</th>
              <th>Proof / Details Submitted</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            ${rows}
          </tbody>
        </table>
      </div>
    `;
  } catch (err) {
    container.innerHTML = '<p style="color:var(--danger); text-align:center;">Failed to load claims.</p>';
  }
}

/**
 * Load claims submitted by other students on user's posted found items
 */
async function loadReceivedClaims(container) {
  try {
    const res = await apiFetch('/claims/read.php?received=true');
    const data = await res.json();

    if (!data.success || !data.claims || data.claims.length === 0) {
      container.innerHTML = '<p style="color:var(--text-muted); font-size:0.9rem; padding:1rem 0;">No claims have been submitted on your posts yet.</p>';
      return;
    }

    const rows = data.claims.map(c => `
      <tr>
        <td>
          <strong>${escapeHtml(c.item_name)}</strong>
          <div style="font-size:0.75rem; color:var(--text-muted);">From: ${escapeHtml(c.claimant_name)} (${escapeHtml(c.claimant_email)})</div>
        </td>
        <td>${formatDate(c.created_at?.split(' ')[0])}</td>
        <td>
          <p style="font-size:0.85rem; margin:0 0 4px 0;">${escapeHtml(c.message)}</p>
          <div style="font-size:0.75rem; color:var(--text-muted);">Contact: ${escapeHtml(c.contact_info)}</div>
        </td>
        <td>
          <span class="badge badge-${escapeHtml(c.status)}">${escapeHtml(c.status)}</span>
        </td>
        <td>
          ${c.status === 'pending' ? `
            <div style="display:flex; gap:0.4rem;">
              <button class="btn btn-success btn-sm" onclick="handleClaimStatus(${c.id}, 'accepted')">Accept</button>
              <button class="btn btn-danger btn-sm" onclick="handleClaimStatus(${c.id}, 'rejected')">Reject</button>
            </div>
          ` : `
            <span style="font-size:0.8rem; color:var(--text-muted);">Reviewed</span>
          `}
        </td>
      </tr>
    `).join('');

    container.innerHTML = `
      <div class="table-responsive" style="margin-top:1rem;">
        <table class="data-table">
          <thead>
            <tr>
              <th>Reported Item & Claimant</th>
              <th>Date</th>
              <th>Submitted Proof</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            ${rows}
          </tbody>
        </table>
      </div>
    `;
  } catch (err) {
    container.innerHTML = '<p style="color:var(--danger);">Error loading received claims.</p>';
  }
}

/**
 * Handle Owner Claim Decision
 */
window.handleClaimStatus = async function(claimId, status) {
  const verb = status === 'accepted' ? 'accept this claim and mark item as returned/claimed' : 'reject this claim';
  if (!confirm(`Are you sure you want to ${verb}?`)) return;

  try {
    const res = await apiFetch('/claims/update.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ claim_id: claimId, status: status })
    });
    const data = await res.json();

    if (data.success) {
      showToast(data.message || `Claim ${status}`, 'success');
      const container = document.getElementById('received-claims-container');
      if (container) loadReceivedClaims(container);
    } else {
      showToast(data.message || 'Action failed', 'error');
    }
  } catch (err) {
    showToast('Network error updating claim.', 'error');
  }
};
