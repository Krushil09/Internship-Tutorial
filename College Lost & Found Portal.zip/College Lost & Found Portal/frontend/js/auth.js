/**
 * CampusFind - College Lost & Found Portal
 * Authentication & Profile Management
 * Pure Vanilla JavaScript
 */

document.addEventListener('DOMContentLoaded', () => {
  // Handle Student Login Form
  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const submitBtn = loginForm.querySelector('button[type="submit"]');
      const email = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value;

      if (!email || !password) {
        showToast('Please enter both email and password.', 'warning');
        return;
      }

      submitBtn.disabled = true;
      submitBtn.textContent = 'Logging in...';

      try {
        const res = await apiFetch('/auth/login.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password, portal: 'student' })
        });
        const data = await res.json();

        if (data.success) {
          showToast(data.message || 'Login successful!', 'success');
          setTimeout(() => {
            window.location.href = data.redirect || 'dashboard.html';
          }, 600);
        } else {
          showToast(data.message || 'Invalid student credentials.', 'error');
          submitBtn.disabled = false;
          submitBtn.textContent = 'Log In';
        }
      } catch (err) {
        showToast('Network or server error during login.', 'error');
        submitBtn.disabled = false;
        submitBtn.textContent = 'Log In';
      }
    });
  }

  // Handle Admin Login Form
  const adminLoginForm = document.getElementById('admin-login-form');
  if (adminLoginForm) {
    adminLoginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const submitBtn = adminLoginForm.querySelector('button[type="submit"]');
      const email = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value;

      if (!email || !password) {
        showToast('Please enter administrator credentials.', 'warning');
        return;
      }

      submitBtn.disabled = true;
      submitBtn.textContent = 'Authenticating...';

      try {
        const res = await apiFetch('/auth/login.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password, portal: 'admin' })
        });
        const data = await res.json();

        if (data.success) {
          showToast(data.message || 'Administrative access granted.', 'success');
          setTimeout(() => {
            window.location.href = 'dashboard.html';
          }, 600);
        } else {
          showToast(data.message || 'Invalid administrator credentials.', 'error');
          submitBtn.disabled = false;
          submitBtn.textContent = 'Sign In to Admin';
        }
      } catch (err) {
        showToast('Server connection error.', 'error');
        submitBtn.disabled = false;
        submitBtn.textContent = 'Sign In to Admin';
      }
    });
  }

  // Handle Student Registration Form
  const registerForm = document.getElementById('register-form');
  if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const submitBtn = registerForm.querySelector('button[type="submit"]');
      const name = document.getElementById('name').value.trim();
      const email = document.getElementById('email').value.trim();
      const phone = document.getElementById('phone').value.trim();
      const password = document.getElementById('password').value;
      const confirmPassword = document.getElementById('confirm_password').value;

      // Client validation
      if (!name || !email || !phone || !password || !confirmPassword) {
        showToast('Please fill in all required registration fields.', 'warning');
        return;
      }

      if (password.length < 6) {
        showToast('Password must be at least 6 characters long.', 'warning');
        return;
      }

      if (password !== confirmPassword) {
        showToast('Password confirmation does not match.', 'error');
        return;
      }

      submitBtn.disabled = true;
      submitBtn.textContent = 'Creating Account...';

      try {
        const res = await apiFetch('/auth/register.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name,
            email,
            phone,
            password,
            confirm_password: confirmPassword
          })
        });
        const data = await res.json();

        if (data.success) {
          showToast(data.message || 'Account created successfully!', 'success');
          setTimeout(() => {
            window.location.href = data.redirect || 'login.html';
          }, 1000);
        } else {
          showToast(data.message || 'Registration failed.', 'error');
          submitBtn.disabled = false;
          submitBtn.textContent = 'Register Account';
        }
      } catch (err) {
        showToast('Network error during registration.', 'error');
        submitBtn.disabled = false;
        submitBtn.textContent = 'Register Account';
      }
    });
  }

  // Handle Profile Page
  const profileForm = document.getElementById('profile-form');
  if (profileForm) {
    loadUserProfile();

    profileForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const submitBtn = profileForm.querySelector('button[type="submit"]');
      const name = document.getElementById('profile-name').value.trim();
      const phone = document.getElementById('profile-phone').value.trim();
      const currentPassword = document.getElementById('current-password').value;
      const newPassword = document.getElementById('new-password').value;

      submitBtn.disabled = true;
      submitBtn.textContent = 'Saving Changes...';

      try {
        const res = await apiFetch('/auth/session.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'update_profile',
            name,
            phone,
            current_password: currentPassword,
            new_password: newPassword
          })
        });
        const data = await res.json();

        if (data.success) {
          showToast(data.message || 'Profile updated successfully!', 'success');
          document.getElementById('current-password').value = '';
          document.getElementById('new-password').value = '';
          loadUserProfile();
        } else {
          showToast(data.message || 'Profile update failed.', 'error');
        }
      } catch (err) {
        showToast('Error updating profile.', 'error');
      } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Update Profile';
      }
    });

    const markReadBtn = document.getElementById('mark-read-btn');
    if (markReadBtn) {
      markReadBtn.addEventListener('click', async () => {
        try {
          const res = await apiFetch('/auth/session.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'mark_notifications_read' })
          });
          const data = await res.json();
          if (data.success) {
            showToast('All notifications marked as read.', 'success');
            loadUserProfile();
          }
        } catch (err) {
          showToast('Failed to update notifications.', 'error');
        }
      });
    }
  }
});

/**
 * Load User Profile & Notifications
 */
async function loadUserProfile() {
  try {
    const res = await apiFetch('/auth/session.php?portal=student');
    const data = await res.json();

    if (!data.logged_in || !data.user) {
      window.location.href = 'login.html';
      return;
    }

    const u = data.user;
    if (document.getElementById('profile-name')) document.getElementById('profile-name').value = u.name;
    if (document.getElementById('profile-email')) document.getElementById('profile-email').value = u.email;
    if (document.getElementById('profile-phone')) document.getElementById('profile-phone').value = u.phone;
    if (document.getElementById('profile-role')) document.getElementById('profile-role').textContent = u.role.toUpperCase();
    if (document.getElementById('profile-created')) document.getElementById('profile-created').textContent = formatDate(u.created_at?.split(' ')[0]);

    // Render Stats
    if (document.getElementById('stat-my-lost')) document.getElementById('stat-my-lost').textContent = data.stats.lost_count || 0;
    if (document.getElementById('stat-my-found')) document.getElementById('stat-my-found').textContent = data.stats.found_count || 0;
    if (document.getElementById('stat-my-claims')) document.getElementById('stat-my-claims').textContent = data.stats.claims_count || 0;
    if (document.getElementById('stat-my-resolved')) document.getElementById('stat-my-resolved').textContent = data.stats.resolved_count || 0;

    // Render Notifications
    const notifList = document.getElementById('notifications-list');
    if (notifList) {
      if (!data.notifications || data.notifications.length === 0) {
        notifList.innerHTML = '<p style="color:var(--text-muted); font-size:0.9rem; text-align:center; padding:1.5rem;">No recent notifications.</p>';
      } else {
        notifList.innerHTML = data.notifications.map(n => `
          <div style="padding:0.875rem 1rem; border-bottom:1px solid var(--border); background:${n.is_read ? 'transparent' : 'var(--primary-light)'}; border-radius:var(--radius-sm); margin-bottom:6px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
              <strong style="color:var(--primary); font-size:0.9rem;">${escapeHtml(n.title)}</strong>
              <span style="font-size:0.75rem; color:var(--text-muted);">${formatDate(n.created_at?.split(' ')[0])}</span>
            </div>
            <p style="font-size:0.85rem; color:var(--text-main); margin:0;">${escapeHtml(n.message)}</p>
          </div>
        `).join('');
      }
    }
  } catch (err) {
    console.error('Failed to load profile:', err);
  }
}
