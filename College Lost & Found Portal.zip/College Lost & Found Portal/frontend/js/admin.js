/**
 * CampusFind - College Lost & Found Portal
 * Administrator Management Script
 * Pure Vanilla JavaScript
 */

document.addEventListener('DOMContentLoaded', () => {
  // Ensure user is an authenticated administrator
  verifyAdminAccess();

  // 1. Admin Dashboard
  const adminStatsContainer = document.getElementById('admin-stats-grid');
  if (adminStatsContainer) {
    loadAdminDashboard();
  }

  // 2. Admin Users Management
  const adminUsersTable = document.getElementById('admin-users-table');
  if (adminUsersTable) {
    initAdminUsers();
  }

  // 3. Admin Items Management
  const adminItemsTable = document.getElementById('admin-items-table');
  if (adminItemsTable) {
    initAdminItems();
  }

  // 4. Admin Claims Management
  const adminClaimsTable = document.getElementById('admin-claims-table');
  if (adminClaimsTable) {
    initAdminClaims();
  }

  // Logout button binding
  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn && typeof handleLogout === 'function') {
    logoutBtn.addEventListener('click', handleLogout);
  }
});

/**
 * Verify Admin Role Server-Side
 */
async function verifyAdminAccess() {
  // Skip check on login page
  if (window.location.pathname.endsWith('login.html')) return;

  try {
    const res = await apiFetch('/auth/session.php?portal=admin');
    if (!res.ok) {
      window.location.href = 'login.html';
      return;
    }
    const data = await res.json();

    if (!data.logged_in || data.user?.role !== 'admin') {
      window.location.href = 'login.html';
    } else {
      const adminNameEl = document.getElementById('admin-name-display');
      if (adminNameEl) adminNameEl.textContent = data.user.name;
    }
  } catch (err) {
    window.location.href = 'login.html';
  }
}

/**
 * Load Admin Dashboard Statistics & Quick Actions
 */
async function loadAdminDashboard() {
  try {
    const res = await apiFetch('/admin/items.php?action=stats');
    const data = await res.json();

    if (!data.success) {
      showToast('Could not load statistics', 'error');
      return;
    }

    const s = data.stats;
    if (document.getElementById('stat-total-users')) document.getElementById('stat-total-users').textContent = s.total_users;
    if (document.getElementById('stat-lost-items')) document.getElementById('stat-lost-items').textContent = s.lost_items;
    if (document.getElementById('stat-found-items')) document.getElementById('stat-found-items').textContent = s.found_items;
    if (document.getElementById('stat-pending-posts')) document.getElementById('stat-pending-posts').textContent = s.pending_posts;
    if (document.getElementById('stat-active-claims')) document.getElementById('stat-active-claims').textContent = s.active_claims;
    if (document.getElementById('stat-resolved-items')) document.getElementById('stat-resolved-items').textContent = s.resolved_items;

    // Render Quick Pending Items
    const pendingContainer = document.getElementById('admin-pending-items-body');
    if (pendingContainer) {
      if (!data.recent_pending || data.recent_pending.length === 0) {
        pendingContainer.innerHTML = '<tr><td colspan="5" style="text-align:center; color:var(--text-muted); padding:2rem;">No pending posts waiting for review. All clear!</td></tr>';
      } else {
        pendingContainer.innerHTML = data.recent_pending.map(item => `
          <tr>
            <td>
              <strong>${escapeHtml(item.item_name)}</strong>
              <div style="font-size:0.75rem; color:var(--text-muted);">${escapeHtml(item.category)} • 📍 ${escapeHtml(item.location)}</div>
            </td>
            <td>
              <span class="item-badge-type ${item.type}" style="position:static;">${item.type.toUpperCase()}</span>
            </td>
            <td>${escapeHtml(item.reporter_name)}</td>
            <td>${formatDate(item.created_at?.split(' ')[0])}</td>
            <td>
              <div style="display:flex; gap:0.4rem;">
                <button class="btn btn-success btn-sm" onclick="adminItemAction(${item.id}, 'approve')">Approve</button>
                <button class="btn btn-danger btn-sm" onclick="adminItemAction(${item.id}, 'reject')">Reject</button>
              </div>
            </td>
          </tr>
        `).join('');
      }
    }

    // Render Recent Claims
    const claimsContainer = document.getElementById('admin-recent-claims-body');
    if (claimsContainer) {
      if (!data.recent_claims || data.recent_claims.length === 0) {
        claimsContainer.innerHTML = '<tr><td colspan="4" style="text-align:center; color:var(--text-muted); padding:2rem;">No recent claims.</td></tr>';
      } else {
        claimsContainer.innerHTML = data.recent_claims.map(c => `
          <tr>
            <td><strong>${escapeHtml(c.item_name)}</strong></td>
            <td>${escapeHtml(c.claimant_name)}</td>
            <td><span class="badge badge-${escapeHtml(c.status)}">${escapeHtml(c.status)}</span></td>
            <td>${formatDate(c.created_at?.split(' ')[0])}</td>
          </tr>
        `).join('');
      }
    }

  } catch (err) {
    showToast('Failed to load dashboard data.', 'error');
  }
}

/**
 * Admin Item Action (Approve, Reject, Resolve, Delete)
 */
window.adminItemAction = async function(itemId, action) {
  if (action === 'delete' && !confirm('Are you sure you want to permanently delete this item?')) return;

  try {
    const res = await apiFetch('/admin/items.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ item_id: itemId, action })
    });
    const data = await res.json();

    if (data.success) {
      showToast(data.message || 'Action executed successfully.', 'success');
      // Reload current view
      if (document.getElementById('admin-pending-items-body')) loadAdminDashboard();
      if (document.getElementById('admin-items-body')) loadAdminItems();
    } else {
      showToast(data.message || 'Action failed.', 'error');
    }
  } catch (err) {
    showToast('Network error processing request.', 'error');
  }
};

/**
 * Initialize Admin Users Management
 */
function initAdminUsers() {
  const searchInput = document.getElementById('user-search');
  const roleFilter = document.getElementById('user-role-filter');
  const statusFilter = document.getElementById('user-status-filter');
  const tbody = document.getElementById('admin-users-body');

  async function fetchUsers() {
    tbody.innerHTML = '<tr><td colspan="7" style="text-align:center; padding:2rem;"><div class="loading-spinner"></div></td></tr>';

    const params = new URLSearchParams();
    if (searchInput && searchInput.value.trim()) params.append('search', searchInput.value.trim());
    if (roleFilter && roleFilter.value) params.append('role', roleFilter.value);
    if (statusFilter && statusFilter.value) params.append('status', statusFilter.value);

    try {
      const res = await apiFetch(`/admin/users.php?${params.toString()}`);
      const data = await res.json();

      if (!data.success || !data.users || data.users.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align:center; color:var(--text-muted); padding:2rem;">No matching user accounts found.</td></tr>';
        return;
      }

      tbody.innerHTML = data.users.map(u => `
        <tr>
          <td>#${u.id}</td>
          <td><strong>${escapeHtml(u.name)}</strong></td>
          <td>${escapeHtml(u.email)}</td>
          <td>${escapeHtml(u.phone)}</td>
          <td>
            <span class="badge ${u.role === 'admin' ? 'badge-claimed' : 'badge-resolved'}">${u.role.toUpperCase()}</span>
          </td>
          <td>
            <span class="badge badge-${escapeHtml(u.status)}">${escapeHtml(u.status)}</span>
          </td>
          <td>
            ${u.role !== 'admin' ? `
              <button class="btn btn-sm ${u.status === 'active' ? 'btn-danger' : 'btn-success'}" onclick="toggleUserStatus(${u.id})">
                ${u.status === 'active' ? 'Deactivate' : 'Activate'}
              </button>
            ` : '<span style="font-size:0.75rem; color:var(--text-muted);">Admin (Protected)</span>'}
          </td>
        </tr>
      `).join('');
    } catch (err) {
      tbody.innerHTML = '<tr><td colspan="7" style="color:var(--danger); text-align:center;">Failed to load users.</td></tr>';
    }
  }

  fetchUsers();

  let debounceTimer;
  if (searchInput) {
    searchInput.addEventListener('input', () => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(fetchUsers, 350);
    });
  }
  if (roleFilter) roleFilter.addEventListener('change', fetchUsers);
  if (statusFilter) statusFilter.addEventListener('change', fetchUsers);
}

/**
 * Toggle User Account Status
 */
window.toggleUserStatus = async function(userId) {
  try {
    const res = await apiFetch('/admin/users.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_id: userId, action: 'toggle_status' })
    });
    const data = await res.json();

    if (data.success) {
      showToast(data.message, 'success');
      initAdminUsers();
    } else {
      showToast(data.message || 'Status change failed', 'error');
    }
  } catch (err) {
    showToast('Error updating user status', 'error');
  }
};

/**
 * Initialize Admin Items Management
 */
function initAdminItems() {
  const searchInput = document.getElementById('item-search');
  const typeFilter = document.getElementById('item-type-filter');
  const statusFilter = document.getElementById('item-status-filter');

  window.loadAdminItems = async function() {
    const tbody = document.getElementById('admin-items-body');
    if (!tbody) return;

    tbody.innerHTML = '<tr><td colspan="8" style="text-align:center; padding:2rem;"><div class="loading-spinner"></div></td></tr>';

    const params = new URLSearchParams();
    if (searchInput && searchInput.value.trim()) params.append('search', searchInput.value.trim());
    if (typeFilter && typeFilter.value) params.append('type', typeFilter.value);
    if (statusFilter && statusFilter.value) params.append('status', statusFilter.value);

    try {
      const res = await apiFetch(`/admin/items.php?${params.toString()}`);
      const data = await res.json();

      if (!data.success || !data.items || data.items.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" style="text-align:center; color:var(--text-muted); padding:2rem;">No items found.</td></tr>';
        return;
      }

      tbody.innerHTML = data.items.map(i => `
        <tr>
          <td>#${i.id}</td>
          <td>
            <div style="display:flex; align-items:center; gap:0.5rem;">
              <div style="width:36px; height:36px; border-radius:4px; overflow:hidden; background:#eee; flex-shrink:0;">
                ${i.image_url ? `<img src="${escapeHtml(i.image_url)}" style="width:100%; height:100%; object-fit:cover;">` : '<div style="display:flex; align-items:center; justify-content:center; height:100%; font-size:12px;">📷</div>'}
              </div>
              <div>
                <strong>${escapeHtml(i.item_name)}</strong>
                <div style="font-size:0.75rem; color:var(--text-muted);">${escapeHtml(i.category)}</div>
              </div>
            </div>
          </td>
          <td><span class="item-badge-type ${i.type}" style="position:static;">${i.type.toUpperCase()}</span></td>
          <td>📍 ${escapeHtml(i.location)}</td>
          <td>${escapeHtml(i.reporter_name)}</td>
          <td><span class="badge badge-${escapeHtml(i.status)}">${escapeHtml(i.status)}</span></td>
          <td>${formatDate(i.item_date)}</td>
          <td>
            <div style="display:flex; gap:0.3rem;">
              ${i.status === 'pending' ? `
                <button class="btn btn-success btn-sm" onclick="adminItemAction(${i.id}, 'approve')">Approve</button>
                <button class="btn btn-danger btn-sm" onclick="adminItemAction(${i.id}, 'reject')">Reject</button>
              ` : ''}
              ${i.status !== 'resolved' ? `
                <button class="btn btn-secondary btn-sm" onclick="adminItemAction(${i.id}, 'resolve')">Resolve</button>
              ` : ''}
              <button class="btn btn-outline btn-sm" onclick="adminItemAction(${i.id}, 'delete')">Delete</button>
            </div>
          </td>
        </tr>
      `).join('');
    } catch (err) {
      tbody.innerHTML = '<tr><td colspan="8" style="color:var(--danger); text-align:center;">Failed to load items.</td></tr>';
    }
  };

  loadAdminItems();

  let debounceTimer;
  if (searchInput) {
    searchInput.addEventListener('input', () => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(loadAdminItems, 350);
    });
  }
  if (typeFilter) typeFilter.addEventListener('change', loadAdminItems);
  if (statusFilter) statusFilter.addEventListener('change', loadAdminItems);
}

/**
 * Initialize Admin Claims Management
 */
function initAdminClaims() {
  const searchInput = document.getElementById('claim-search');
  const statusFilter = document.getElementById('claim-status-filter');
  const tbody = document.getElementById('admin-claims-body');

  async function fetchClaims() {
    tbody.innerHTML = '<tr><td colspan="7" style="text-align:center; padding:2rem;"><div class="loading-spinner"></div></td></tr>';

    const params = new URLSearchParams();
    if (searchInput && searchInput.value.trim()) params.append('search', searchInput.value.trim());
    if (statusFilter && statusFilter.value) params.append('status', statusFilter.value);

    try {
      const res = await apiFetch(`/admin/claims.php?${params.toString()}`);
      const data = await res.json();

      if (!data.success || !data.claims || data.claims.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align:center; color:var(--text-muted); padding:2rem;">No claims found.</td></tr>';
        return;
      }

      tbody.innerHTML = data.claims.map(c => `
        <tr>
          <td>#${c.id}</td>
          <td><strong>${escapeHtml(c.item_name)}</strong></td>
          <td>
            <strong>${escapeHtml(c.claimant_name)}</strong>
            <div style="font-size:0.75rem; color:var(--text-muted);">${escapeHtml(c.claimant_email)}</div>
          </td>
          <td>${escapeHtml(c.reporter_name)}</td>
          <td>
            <p style="font-size:0.85rem; margin:0 0 2px 0;">${escapeHtml(c.message)}</p>
            <span style="font-size:0.75rem; color:var(--text-muted);">Contact: ${escapeHtml(c.contact_info)}</span>
          </td>
          <td><span class="badge badge-${escapeHtml(c.status)}">${escapeHtml(c.status)}</span></td>
          <td>
            ${c.status === 'pending' ? `
              <div style="display:flex; gap:0.3rem;">
                <button class="btn btn-success btn-sm" onclick="adminClaimDecision(${c.id}, 'accepted')">Accept</button>
                <button class="btn btn-danger btn-sm" onclick="adminClaimDecision(${c.id}, 'rejected')">Reject</button>
              </div>
            ` : '<span style="font-size:0.8rem; color:var(--text-muted);">Decided</span>'}
          </td>
        </tr>
      `).join('');
    } catch (err) {
      tbody.innerHTML = '<tr><td colspan="7" style="color:var(--danger); text-align:center;">Failed to load claims.</td></tr>';
    }
  }

  fetchClaims();

  let debounceTimer;
  if (searchInput) {
    searchInput.addEventListener('input', () => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(fetchClaims, 350);
    });
  }
  if (statusFilter) statusFilter.addEventListener('change', fetchClaims);
}

/**
 * Handle Admin Claim Decision
 */
window.adminClaimDecision = async function(claimId, status) {
  if (!confirm(`Are you sure you want to mark this claim as ${status.toUpperCase()}?`)) return;

  try {
    const res = await apiFetch('/admin/claims.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ claim_id: claimId, status })
    });
    const data = await res.json();

    if (data.success) {
      showToast(data.message, 'success');
      initAdminClaims();
    } else {
      showToast(data.message || 'Failed to update claim.', 'error');
    }
  } catch (err) {
    showToast('Error processing claim decision.', 'error');
  }
};
