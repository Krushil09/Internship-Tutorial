/**
 * CampusFind - College Lost & Found Portal
 * Items Management Script (Browse, Filter, Report, Details, My Posts)
 * Pure Vanilla JavaScript
 */

document.addEventListener('DOMContentLoaded', () => {
  // 1. Home Page: Load Recent Items
  const recentGrid = document.getElementById('recent-items-grid');
  if (recentGrid) {
    loadRecentItems(recentGrid);
  }

  // 2. Lost Items Page
  const lostGrid = document.getElementById('lost-items-grid');
  if (lostGrid) {
    initBrowseItems('lost', lostGrid);
  }

  // 3. Found Items Page
  const foundGrid = document.getElementById('found-items-grid');
  if (foundGrid) {
    initBrowseItems('found', foundGrid);
  }

  // 4. Report Lost Item Form
  const reportLostForm = document.getElementById('report-lost-form');
  if (reportLostForm) {
    initReportForm(reportLostForm, 'lost');
  }

  // 5. Report Found Item Form
  const reportFoundForm = document.getElementById('report-found-form');
  if (reportFoundForm) {
    initReportForm(reportFoundForm, 'found');
  }

  // 6. Item Details Page
  const itemDetailsContainer = document.getElementById('item-details-container');
  if (itemDetailsContainer) {
    loadItemDetails(itemDetailsContainer);
  }

  // 7. My Posts Page
  const myPostsContainer = document.getElementById('my-posts-container');
  if (myPostsContainer) {
    loadMyPosts(myPostsContainer);
  }

  // 8. Student Dashboard Stats & Recent Posts
  const dashboardStats = document.getElementById('dashboard-stats-container');
  if (dashboardStats) {
    loadDashboardData();
  }
});

/**
 * Load Recent Items on Home Page
 */
async function loadRecentItems(container) {
  try {
    container.innerHTML = '<div style="grid-column: 1/-1; text-align:center; padding:2rem;"><div class="loading-spinner"></div><p style="margin-top:0.5rem; color:var(--text-muted);">Loading recent campus reports...</p></div>';
    const res = await apiFetch('/items/read.php?recent=true');
    const data = await res.json();

    if (!data.success || !data.items || data.items.length === 0) {
      container.innerHTML = `
        <div class="empty-state" style="grid-column: 1/-1;">
          <div class="empty-state-icon">📋</div>
          <h3 class="empty-state-title">No Recent Reports</h3>
          <p class="empty-state-text">There are currently no active lost or found items reported on campus.</p>
          <a href="report-lost.html" class="btn btn-primary btn-sm">Report an Item</a>
        </div>
      `;
      return;
    }

    container.innerHTML = data.items.map(renderItemCardHtml).join('');
  } catch (err) {
    container.innerHTML = '<p style="grid-column: 1/-1; color:var(--danger); text-align:center;">Failed to load recent items from backend.</p>';
  }
}

/**
 * Initialize Browse Items (Lost / Found) with Live Filters
 */
function initBrowseItems(type, container) {
  const searchInput = document.getElementById('search-input');
  const categorySelect = document.getElementById('category-filter');
  const locationInput = document.getElementById('location-filter');
  const dateInput = document.getElementById('date-filter');
  const filterForm = document.getElementById('filter-form');
  const resetBtn = document.getElementById('reset-filters-btn');
  const countBadge = document.getElementById('items-count-badge');

  async function fetchAndRender() {
    container.innerHTML = '<div style="grid-column: 1/-1; text-align:center; padding:3rem;"><div class="loading-spinner"></div><p style="margin-top:0.5rem; color:var(--text-muted);">Fetching reports...</p></div>';

    const params = new URLSearchParams({ type });
    if (searchInput && searchInput.value.trim()) params.append('search', searchInput.value.trim());
    if (categorySelect && categorySelect.value && categorySelect.value !== 'All') params.append('category', categorySelect.value);
    if (locationInput && locationInput.value.trim()) params.append('location', locationInput.value.trim());
    if (dateInput && dateInput.value) params.append('date_from', dateInput.value);

    try {
      const res = await apiFetch(`/items/read.php?${params.toString()}`);
      const data = await res.json();

      if (countBadge) countBadge.textContent = `${data.count || 0} items`;

      if (!data.success || !data.items || data.items.length === 0) {
        container.innerHTML = `
          <div class="empty-state" style="grid-column: 1/-1;">
            <div class="empty-state-icon">🔍</div>
            <h3 class="empty-state-title">No Items Found</h3>
            <p class="empty-state-text">No ${type} items match your filter criteria. Try adjusting your search keywords or category.</p>
            <a href="report-${type}.html" class="btn btn-primary btn-sm">Report a ${type === 'lost' ? 'Lost' : 'Found'} Item</a>
          </div>
        `;
        return;
      }

      container.innerHTML = data.items.map(renderItemCardHtml).join('');
    } catch (err) {
      container.innerHTML = '<p style="grid-column: 1/-1; color:var(--danger); text-align:center;">Network error loading items.</p>';
    }
  }

  // Initial load
  fetchAndRender();

  // Search input debounced
  let debounceTimer;
  if (searchInput) {
    searchInput.addEventListener('input', () => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(fetchAndRender, 350);
    });
  }

  if (categorySelect) categorySelect.addEventListener('change', fetchAndRender);
  if (locationInput) {
    locationInput.addEventListener('input', () => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(fetchAndRender, 350);
    });
  }
  if (dateInput) dateInput.addEventListener('change', fetchAndRender);

  if (filterForm) {
    filterForm.addEventListener('submit', (e) => {
      e.preventDefault();
      fetchAndRender();
    });
  }

  if (resetBtn) {
    resetBtn.addEventListener('click', (e) => {
      e.preventDefault();
      if (searchInput) searchInput.value = '';
      if (categorySelect) categorySelect.value = 'All';
      if (locationInput) locationInput.value = '';
      if (dateInput) dateInput.value = '';
      fetchAndRender();
    });
  }
}

/**
 * Render Item Card HTML
 */
function renderItemCardHtml(item) {
  const typeClass = item.type === 'lost' ? 'lost' : 'found';
  const typeLabel = item.type === 'lost' ? 'LOST' : 'FOUND';

  const mediaHtml = item.image_url
    ? `<img src="${escapeHtml(item.image_url)}" alt="${escapeHtml(item.item_name)}" loading="lazy">`
    : getItemPlaceholderSvg(item.category, item.type);

  return `
    <div class="item-card">
      <div class="item-card-media">
        ${mediaHtml}
        <span class="item-badge-type ${typeClass}">${typeLabel}</span>
        <span class="item-badge-status badge-${escapeHtml(item.status)}">${escapeHtml(item.status)}</span>
      </div>
      <div class="item-card-body">
        <span class="item-category-tag">${escapeHtml(item.category)}</span>
        <h3 class="item-card-title">${escapeHtml(item.item_name)}</h3>
        <p class="item-card-desc">${escapeHtml(item.description)}</p>
        
        <div class="item-meta-list">
          <div class="item-meta-row">
            <span>📍</span>
            <span><strong>Location:</strong> ${escapeHtml(item.location)}</span>
          </div>
          <div class="item-meta-row">
            <span>📅</span>
            <span><strong>Date:</strong> ${formatDate(item.item_date)}</span>
          </div>
        </div>

        <div class="item-card-footer">
          <a href="item-details.html?id=${item.id}" class="btn btn-outline btn-sm btn-block">View Details</a>
        </div>
      </div>
    </div>
  `;
}

/**
 * Initialize Report Lost or Found Item Form
 */
function initReportForm(form, type) {
  initImageUploadPreview('item-image', 'preview-container', 'preview-img', 'preview-remove');

  // Set default date to today
  const dateInput = document.getElementById('item_date');
  if (dateInput && !dateInput.value) {
    const today = new Date().toISOString().split('T')[0];
    dateInput.value = today;
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const submitBtn = form.querySelector('button[type="submit"]');

    const itemName = document.getElementById('item_name').value.trim();
    const category = document.getElementById('category').value;
    const description = document.getElementById('description').value.trim();
    const location = document.getElementById('location').value.trim();
    const itemDate = document.getElementById('item_date').value;
    const approxTime = document.getElementById('approx_time') ? document.getElementById('approx_time').value.trim() : '';
    const additionalInfo = document.getElementById('additional_info') ? document.getElementById('additional_info').value.trim() : '';
    const imageInput = document.getElementById('item-image');

    // Validation
    if (!itemName || !category || !description || !location || !itemDate) {
      showToast('Please fill in all required fields marked with *', 'warning');
      return;
    }

    const formData = new FormData();
    formData.append('type', type);
    formData.append('item_name', itemName);
    formData.append('category', category);
    formData.append('description', description);
    formData.append('location', location);
    formData.append('item_date', itemDate);
    formData.append('approx_time', approxTime);
    formData.append('additional_info', additionalInfo);

    if (imageInput && imageInput.files && imageInput.files[0]) {
      formData.append('image', imageInput.files[0]);
    }

    submitBtn.disabled = true;
    submitBtn.textContent = 'Submitting Report...';

    try {
      const res = await apiFetch('/items/create.php', {
        method: 'POST',
        body: formData
      });
      const data = await res.json();

      if (data.success) {
        showToast(data.message || 'Report submitted successfully!', 'success');
        setTimeout(() => {
          window.location.href = data.redirect || 'my-posts.html';
        }, 1000);
      } else {
        showToast(data.message || 'Failed to submit item report.', 'error');
        submitBtn.disabled = false;
        submitBtn.textContent = 'Submit Report';
      }
    } catch (err) {
      showToast('Server error while submitting report.', 'error');
      submitBtn.disabled = false;
      submitBtn.textContent = 'Submit Report';
    }
  });
}

/**
 * Load Item Details Page
 */
async function loadItemDetails(container) {
  const urlParams = new URLSearchParams(window.location.search);
  const itemId = urlParams.get('id');

  if (!itemId) {
    container.innerHTML = `
      <div class="empty-state">
        <h3 class="empty-state-title">No Item Specified</h3>
        <p class="empty-state-text">Please select an item from the lost or found directory.</p>
        <a href="lost-items.html" class="btn btn-primary btn-sm">Browse Lost Items</a>
      </div>
    `;
    return;
  }

  container.innerHTML = '<div style="text-align:center; padding:4rem;"><div class="loading-spinner"></div><p style="margin-top:0.5rem; color:var(--text-muted);">Loading item details...</p></div>';

  try {
    const res = await apiFetch(`/items/details.php?id=${itemId}`);
    const data = await res.json();

    if (!data.success || !data.item) {
      container.innerHTML = `
        <div class="empty-state">
          <h3 class="empty-state-title">Item Not Found</h3>
          <p class="empty-state-text">${escapeHtml(data.message || 'This item could not be retrieved.')}</p>
          <a href="index.html" class="btn btn-secondary btn-sm">Return to Home</a>
        </div>
      `;
      return;
    }

    const item = data.item;
    const isOwner = data.is_owner;
    const userHasClaimed = data.user_has_claimed;
    const typeLabel = item.type === 'lost' ? 'LOST ITEM' : 'FOUND ITEM';
    const typeClass = item.type === 'lost' ? 'lost' : 'found';

    const mediaHtml = item.image_url
      ? `<img src="${escapeHtml(item.image_url)}" alt="${escapeHtml(item.item_name)}">`
      : getItemPlaceholderSvg(item.category, item.type);

    let actionButtonHtml = '';

    if (isOwner) {
      actionButtonHtml = `
        <span class="badge badge-approved" style="padding:0.5rem 1rem; font-size:0.9rem;">You reported this item</span>
        <button id="mark-resolved-btn" class="btn btn-outline btn-sm">Mark as Resolved</button>
      `;
    } else if (userHasClaimed) {
      actionButtonHtml = `
        <div style="background:var(--success-bg); border:1px solid #C8E6C9; padding:0.75rem 1rem; border-radius:var(--radius-md); color:var(--success); font-weight:600; font-size:0.875rem;">
          ✓ You have submitted an ownership claim for this item (Status: ${escapeHtml(data.user_claim?.status || 'Pending')}).
        </div>
      `;
    } else if (item.status === 'resolved') {
      actionButtonHtml = `
        <span class="badge badge-resolved" style="padding:0.5rem 1rem; font-size:0.9rem;">Case Closed / Reunited with Owner</span>
      `;
    } else {
      actionButtonHtml = `
        <button id="open-claim-modal-btn" class="btn btn-primary">
          <span>✋</span> I Think This Is Mine / Submit Claim
        </button>
      `;
    }

    container.innerHTML = `
      <div class="item-details-layout">
        <div class="item-details-media">
          ${mediaHtml}
        </div>
        <div class="item-details-info">
          <div class="item-details-header">
            <div style="display:flex; justify-content:space-between; align-items:center;">
              <span class="item-badge-type ${typeClass}" style="position:static;">${typeLabel}</span>
              <span class="badge badge-${escapeHtml(item.status)}">${escapeHtml(item.status)}</span>
            </div>
            <h1 class="item-details-title">${escapeHtml(item.item_name)}</h1>
            <p style="color:var(--text-muted); font-size:0.875rem;">Reported on ${formatDate(item.created_at?.split(' ')[0])} by <strong>${escapeHtml(item.reporter_name || 'Campus Member')}</strong></p>
          </div>

          <table class="details-spec-table">
            <tbody>
              <tr>
                <td class="spec-label">Category</td>
                <td class="spec-val"><strong>${escapeHtml(item.category)}</strong></td>
              </tr>
              <tr>
                <td class="spec-label">Location</td>
                <td class="spec-val">📍 ${escapeHtml(item.location)}</td>
              </tr>
              <tr>
                <td class="spec-label">Date ${item.type === 'lost' ? 'Lost' : 'Found'}</td>
                <td class="spec-val">📅 ${formatDate(item.item_date)} ${item.approx_time ? `(${escapeHtml(item.approx_time)})` : ''}</td>
              </tr>
              <tr>
                <td class="spec-label">Description</td>
                <td class="spec-val">${escapeHtml(item.description)}</td>
              </tr>
              ${item.additional_info ? `
              <tr>
                <td class="spec-label">Additional Info</td>
                <td class="spec-val" style="color:var(--secondary); font-style:italic;">${escapeHtml(item.additional_info)}</td>
              </tr>
              ` : ''}
            </tbody>
          </table>

          <div class="details-actions">
            ${actionButtonHtml}
            <a href="${item.type === 'lost' ? 'lost-items.html' : 'found-items.html'}" class="btn btn-secondary">Back to Directory</a>
          </div>
        </div>
      </div>
    `;

    // Hook claim modal button
    const claimBtn = document.getElementById('open-claim-modal-btn');
    if (claimBtn) {
      claimBtn.addEventListener('click', () => {
        if (!window.currentUser) {
          showToast('Please log in first to submit an ownership claim.', 'warning');
          setTimeout(() => { window.location.href = `login.html?redirect=item-details.html?id=${itemId}`; }, 1000);
          return;
        }
        document.getElementById('claim-item-id').value = itemId;
        document.getElementById('claim-item-title').textContent = item.item_name;
        openModal('claim-modal');
      });
    }

    // Hook mark resolved button for owner
    const resolveBtn = document.getElementById('mark-resolved-btn');
    if (resolveBtn) {
      resolveBtn.addEventListener('click', async () => {
        if (!confirm('Are you sure you want to mark this item report as Resolved?')) return;
        try {
          const res = await apiFetch('/items/update.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: itemId, action: 'status_change', status: 'resolved' })
          });
          const updateData = await res.json();
          if (updateData.success) {
            showToast('Item marked as resolved!', 'success');
            loadItemDetails(container);
          } else {
            showToast(updateData.message || 'Failed to update status.', 'error');
          }
        } catch (err) {
          showToast('Error updating item.', 'error');
        }
      });
    }

  } catch (err) {
    container.innerHTML = '<p style="color:var(--danger); text-align:center;">Failed to load item details.</p>';
  }
}

/**
 * Load User's Posts in my-posts.html
 */
async function loadMyPosts(container) {
  try {
    container.innerHTML = '<div style="text-align:center; padding:3rem;"><div class="loading-spinner"></div><p style="margin-top:0.5rem; color:var(--text-muted);">Loading your posts...</p></div>';
    const res = await apiFetch('/items/read.php?mine=true');
    const data = await res.json();

    if (!data.success || !data.items || data.items.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">📝</div>
          <h3 class="empty-state-title">You Haven't Reported Any Items</h3>
          <p class="empty-state-text">Report any items you have lost or found on campus to help reconnect belongings.</p>
          <div style="display:flex; justify-content:center; gap:0.75rem;">
            <a href="report-lost.html" class="btn btn-primary btn-sm">Report Lost Item</a>
            <a href="report-found.html" class="btn btn-secondary btn-sm">Report Found Item</a>
          </div>
        </div>
      `;
      return;
    }

    const rowsHtml = data.items.map(item => `
      <tr>
        <td>
          <div style="display:flex; align-items:center; gap:0.75rem;">
            <div style="width:48px; height:48px; border-radius:var(--radius-sm); overflow:hidden; background:#eee; flex-shrink:0;">
              ${item.image_url ? `<img src="${escapeHtml(item.image_url)}" style="width:100%; height:100%; object-fit:cover;">` : getItemPlaceholderSvg(item.category, item.type)}
            </div>
            <div>
              <a href="item-details.html?id=${item.id}" style="font-weight:600; color:var(--primary);">${escapeHtml(item.item_name)}</a>
              <div style="font-size:0.75rem; color:var(--text-muted);">${escapeHtml(item.category)} • 📍 ${escapeHtml(item.location)}</div>
            </div>
          </div>
        </td>
        <td>
          <span class="item-badge-type ${item.type}" style="position:static;">${item.type.toUpperCase()}</span>
        </td>
        <td>${formatDate(item.item_date)}</td>
        <td>
          <span class="badge badge-${escapeHtml(item.status)}">${escapeHtml(item.status)}</span>
        </td>
        <td>
          <span style="font-weight:600; color:${item.claims_count > 0 ? 'var(--primary)' : 'var(--text-muted)'};">
            ${item.claims_count} claim(s)
          </span>
        </td>
        <td>
          <div style="display:flex; gap:0.4rem;">
            <a href="item-details.html?id=${item.id}" class="btn btn-secondary btn-sm">View</a>
            <button class="btn btn-danger btn-sm" onclick="handleDeleteItem(${item.id}, '${escapeHtml(item.item_name)}')">Delete</button>
          </div>
        </td>
      </tr>
    `).join('');

    container.innerHTML = `
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Item</th>
              <th>Type</th>
              <th>Date</th>
              <th>Status</th>
              <th>Claims</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
          </tbody>
        </table>
      </div>
    `;
  } catch (err) {
    container.innerHTML = '<p style="color:var(--danger); text-align:center;">Failed to load your posts.</p>';
  }
}

/**
 * Global Delete Item Handler
 */
window.handleDeleteItem = async function(id, name) {
  if (!confirm(`Are you sure you want to permanently delete your post "${name}"?`)) return;

  try {
    const res = await apiFetch('/items/delete.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    });
    const data = await res.json();

    if (data.success) {
      showToast(data.message || 'Item deleted successfully', 'success');
      const container = document.getElementById('my-posts-container');
      if (container) loadMyPosts(container);
    } else {
      showToast(data.message || 'Failed to delete item.', 'error');
    }
  } catch (err) {
    showToast('Network error deleting item.', 'error');
  }
};

/**
 * Load Dashboard Quick Data
 */
async function loadDashboardData() {
  try {
    const res = await apiFetch('/auth/session.php?portal=student');
    const data = await res.json();

    if (!data.logged_in || !data.user) {
      window.location.href = 'login.html';
      return;
    }

    if (data.user.role === 'admin') {
      window.location.href = 'admin/dashboard.html';
      return;
    }

    if (document.getElementById('dash-user-name')) {
      document.getElementById('dash-user-name').textContent = data.user.name;
    }

    // Set stat counters
    if (document.getElementById('dash-lost-count')) document.getElementById('dash-lost-count').textContent = data.stats.lost_count || 0;
    if (document.getElementById('dash-found-count')) document.getElementById('dash-found-count').textContent = data.stats.found_count || 0;
    if (document.getElementById('dash-claims-count')) document.getElementById('dash-claims-count').textContent = data.stats.claims_count || 0;
    if (document.getElementById('dash-resolved-count')) document.getElementById('dash-resolved-count').textContent = data.stats.resolved_count || 0;

    // Load recent user posts
    const myRecentContainer = document.getElementById('dash-recent-posts');
    if (myRecentContainer) {
      const itemsRes = await apiFetch('/items/read.php?mine=true&limit=4');
      const itemsData = await itemsRes.json();

      if (itemsData.success && itemsData.items && itemsData.items.length > 0) {
        myRecentContainer.innerHTML = itemsData.items.map(renderItemCardHtml).join('');
      } else {
        myRecentContainer.innerHTML = '<p style="color:var(--text-muted); text-align:center; grid-column:1/-1; padding:2rem;">No posts submitted yet. Click above to report an item.</p>';
      }
    }
  } catch (err) {
    console.error('Dashboard load error:', err);
  }
}
